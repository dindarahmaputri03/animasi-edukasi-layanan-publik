(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_1", frames: [[1726,340,315,41],[538,185,257,77],[1992,0,43,51],[1992,53,43,51],[1986,106,43,51],[2023,426,20,51],[1456,346,43,51],[336,325,243,68],[1978,426,43,51],[0,476,315,36],[0,264,280,68],[1902,471,43,51],[1947,479,43,51],[1992,479,43,51],[1592,53,308,77],[1098,506,43,51],[1726,383,315,41],[0,185,267,77],[1143,506,43,51],[1188,506,43,51],[1233,512,43,51],[0,0,477,51],[0,106,308,77],[1278,512,43,51],[581,389,315,41],[1323,512,43,51],[1368,512,43,51],[1413,512,43,51],[1458,512,43,51],[898,389,315,41],[269,185,267,77],[1503,512,43,51],[1548,512,43,51],[1593,512,43,51],[310,106,308,77],[1638,512,43,51],[0,390,315,41],[1683,512,43,51],[1728,512,43,51],[1773,512,43,51],[479,0,477,51],[1215,420,315,41],[603,279,236,77],[1818,512,43,51],[0,514,43,51],[45,514,43,51],[581,325,20,62],[620,106,308,77],[90,514,43,51],[1532,426,315,41],[135,514,43,51],[180,514,43,51],[225,514,43,51],[317,432,315,41],[841,346,354,41],[270,514,43,51],[315,518,43,51],[360,518,43,51],[1485,565,20,62],[634,432,315,41],[405,518,43,51],[450,518,43,51],[495,518,43,51],[1507,565,20,62],[0,433,315,41],[540,518,43,51],[585,518,43,51],[630,518,43,51],[1529,565,20,62],[958,0,477,51],[951,463,315,41],[1288,132,305,77],[675,518,43,51],[720,518,43,51],[765,518,43,51],[1551,565,20,51],[810,518,43,51],[1268,469,315,41],[1595,193,257,77],[855,518,43,51],[900,518,43,51],[1863,524,43,51],[958,53,315,77],[1908,532,43,51],[1585,469,315,41],[1953,532,43,51],[1998,532,43,51],[945,551,43,51],[1437,0,477,51],[1275,53,315,77],[797,200,257,77],[990,551,43,51],[1035,551,43,51],[1080,559,43,51],[1056,211,257,77],[1125,559,43,51],[1170,559,43,51],[0,53,477,51],[317,475,315,41],[1315,211,257,77],[1215,565,43,51],[1260,565,43,51],[1305,565,43,51],[479,53,477,51],[634,475,315,41],[1197,346,257,41],[1350,565,43,51],[1395,565,43,51],[1440,565,43,51],[1574,272,278,66],[951,506,145,43],[841,290,334,54],[1177,290,334,54],[0,334,334,54],[930,132,356,66],[1513,340,211,78],[1595,132,389,59],[1916,0,74,43],[1916,45,74,43],[1902,426,74,43],[1854,240,186,43],[1854,285,178,43],[1854,193,184,45],[282,264,319,59]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_2", frames: [[0,0,709,59],[711,0,709,59],[0,61,709,59],[711,61,709,59],[0,122,709,59],[711,122,709,59],[0,183,709,59],[711,183,709,59],[0,244,709,59],[711,244,709,59],[0,305,709,59],[1408,1006,454,62],[912,1511,335,77],[1408,1070,454,62],[711,305,709,59],[0,366,709,59],[711,366,709,59],[0,427,709,59],[711,427,709,59],[0,488,709,59],[711,488,709,59],[0,549,709,59],[1602,1906,243,101],[729,1103,454,62],[1422,154,292,133],[0,1150,454,62],[1185,1134,454,62],[912,1590,335,77],[456,1167,454,62],[1408,953,556,51],[0,1214,454,62],[1422,672,267,114],[912,1669,335,77],[912,1198,454,62],[1716,154,308,114],[456,1231,454,62],[912,1748,335,77],[0,1278,454,62],[1368,1198,454,62],[1691,672,267,114],[912,1827,335,77],[0,1342,454,62],[912,1405,533,51],[0,1406,454,62],[912,1906,335,77],[0,1470,454,62],[0,1534,454,62],[1408,788,267,114],[1249,1511,335,77],[0,1598,454,62],[0,1662,454,62],[1586,1511,335,77],[0,1726,454,62],[0,1790,454,62],[1677,788,354,77],[1249,1590,335,77],[0,1854,454,62],[0,1918,454,62],[1368,1326,354,77],[1586,1590,335,77],[0,1982,454,62],[912,1262,454,62],[1249,1669,335,77],[456,1295,454,62],[1719,364,292,114],[1368,1262,454,62],[1586,1669,335,77],[456,1359,454,62],[456,1423,454,62],[1422,364,295,114],[1249,1748,335,77],[456,1487,454,62],[1447,1405,533,51],[456,1551,454,62],[1586,1748,335,77],[456,1615,454,62],[456,1679,454,62],[1249,1827,335,77],[456,1743,454,62],[912,1458,533,51],[456,1807,454,62],[1249,1906,335,77],[456,1871,454,62],[1447,1458,533,51],[456,1935,454,62],[1586,1827,335,77],[912,1326,454,62],[0,732,702,51],[704,732,702,51],[0,785,702,51],[704,785,702,51],[0,838,702,51],[704,838,702,51],[0,891,702,51],[704,891,702,51],[0,944,702,51],[704,944,702,51],[0,997,702,51],[704,997,702,51],[0,1050,702,51],[704,1050,702,51],[711,549,709,59],[0,610,709,59],[711,610,709,59],[0,671,709,59],[711,671,709,59],[1422,0,521,75],[1422,77,521,75],[1422,289,521,73],[1408,904,632,47],[1061,1985,539,47],[1422,480,533,62],[1422,544,533,62],[1422,608,533,62],[0,1103,727,45],[456,1999,603,45]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_3", frames: [[0,1703,709,59],[0,1764,709,59],[0,1825,709,59],[0,1886,709,59],[0,1947,709,59],[479,1402,709,59],[958,1317,709,59],[1190,1378,709,59],[1190,1439,709,59],[479,1463,709,59],[479,1524,709,59],[479,1585,709,59],[1190,1500,709,59],[1190,1561,709,59],[1190,1622,709,59],[711,1683,709,59],[711,1744,709,59],[711,1805,709,59],[711,1866,709,59],[711,1927,709,59],[1169,817,533,98],[1294,717,556,98],[1560,1117,477,98],[611,802,556,98],[535,1202,477,98],[0,803,556,98],[0,1203,477,98],[0,0,822,99],[824,0,822,99],[558,902,533,98],[1014,1217,477,98],[0,101,822,99],[0,903,533,98],[479,1302,477,98],[824,101,822,99],[1093,917,533,98],[0,1303,477,98],[0,202,822,99],[535,1002,533,98],[1493,1217,477,98],[824,202,822,99],[0,1003,533,98],[0,303,822,99],[1070,1017,533,98],[0,1403,477,98],[824,303,822,99],[535,1102,533,98],[0,1503,477,98],[0,404,822,99],[824,404,822,99],[1070,1117,488,98],[0,1603,477,98],[0,505,822,99],[824,505,822,99],[0,1103,533,98],[0,606,702,99],[704,606,702,94],[0,707,609,94],[704,702,588,98],[1408,606,558,109],[1648,0,256,256]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_4", frames: [[0,0,795,126],[797,0,795,126],[0,128,795,126],[797,128,795,126],[0,256,795,126],[797,256,795,126],[0,384,795,126],[797,384,795,126],[0,512,795,126],[797,512,795,126],[0,640,795,126],[797,640,795,126],[0,768,795,126],[797,768,795,126],[0,896,795,126],[797,1536,822,99],[797,896,795,126],[0,1024,795,126],[797,1024,795,126],[0,1152,795,126],[797,1152,795,126],[0,1280,795,126],[797,1280,795,126],[0,1408,795,126],[797,1637,822,99],[797,1738,822,99],[797,1839,822,99],[797,1940,822,99],[0,1536,795,126],[0,1664,795,126],[0,1792,795,126],[0,1920,795,126],[797,1408,795,126]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_5", frames: [[979,473,795,126],[979,601,795,126],[979,729,795,126],[1235,857,795,126],[1235,985,795,126],[1235,1113,795,126],[1235,1241,795,126],[1235,1369,795,126],[0,1455,795,126],[797,1497,795,126],[0,1583,795,126],[797,1625,795,126],[0,1711,795,126],[797,1753,795,126],[0,1839,795,126],[797,1881,795,126],[0,1051,1233,99],[0,903,1233,146],[0,1152,1233,99],[0,1253,1233,99],[0,1354,1233,99],[0,0,460,471],[462,0,460,471],[924,0,460,471],[0,473,501,428],[503,473,474,417]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_6", frames: [[0,0,460,471],[0,473,460,471],[0,946,460,471],[0,1419,460,471],[462,0,460,471],[924,0,460,471],[1386,0,460,471],[462,473,460,471],[462,946,460,471],[462,1419,460,471],[924,473,460,471],[1386,473,460,471],[924,946,460,471],[924,1419,460,471],[1386,946,460,471],[1386,1419,460,471]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_7", frames: [[0,0,460,471],[0,473,460,471],[0,946,460,471],[0,1419,460,471],[462,0,460,471],[924,0,460,471],[1386,0,460,471],[462,473,460,471],[462,946,460,471],[462,1419,460,471],[924,473,460,471],[1386,473,460,471],[924,946,460,471],[924,1419,460,471],[1386,946,460,471],[1386,1419,460,471]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_8", frames: [[0,0,469,487],[0,489,469,487],[0,978,469,487],[0,1467,469,487],[471,0,469,487],[942,0,469,487],[1413,0,469,487],[471,489,469,487],[471,978,469,487],[1437,978,460,471],[942,1426,460,471],[1404,1451,460,471],[471,1467,469,487],[942,489,469,487],[1413,489,469,487],[942,978,493,446]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_9", frames: [[0,0,469,487],[0,489,469,487],[0,978,469,487],[0,1467,469,487],[471,0,469,487],[942,0,469,487],[1413,0,469,487],[471,489,469,487],[471,978,469,487],[471,1467,469,487],[942,489,469,487],[1413,489,469,487],[942,978,469,487],[942,1467,469,487],[1413,978,469,487],[1413,1467,469,487]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_10", frames: [[0,559,1233,193],[940,0,469,487],[1235,489,469,487],[1411,0,469,487],[0,754,469,487],[471,754,469,487],[942,978,469,487],[0,1243,469,487],[471,1243,469,487],[1413,978,469,487],[942,1467,469,487],[1413,1467,469,487],[0,0,489,557],[491,0,447,554]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_11", frames: [[0,1420,1233,241],[0,456,1233,335],[0,1663,1233,241],[0,1130,1233,288],[0,793,1233,335],[0,0,1023,454],[1235,1306,536,544],[1235,0,576,639],[1235,641,551,663]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_12", frames: [[0,432,1233,382],[0,0,1233,430],[0,816,1233,382],[0,1200,1233,382],[0,1584,1233,382]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_13", frames: [[0,0,1203,477],[0,479,1203,477],[0,958,1203,477],[0,1437,1203,477]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_14", frames: [[0,1505,1203,477],[0,1026,1233,477],[0,0,1024,1024]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_15", frames: [[0,0,1024,1024]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_16", frames: [[0,0,1024,1024]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_17", frames: [[0,0,1024,1024]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_18", frames: [[0,0,1024,1024]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_19", frames: [[0,0,1024,1024]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_20", frames: [[0,855,1024,1024],[0,0,1280,853]]},
		{name:"Edukasi Pelayanan Publik _Terbaru__atlas_21", frames: [[0,0,1275,1011],[0,1013,1280,853]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_894 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_893 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_891 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_890 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_888 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_887 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_885 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_884 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_882 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_881 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_880 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_879 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_877 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_876 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_874 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_873 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_872 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_871 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_869 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_868 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_866 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_865 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_864 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_863 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_861 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_860 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_858 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_857 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_855 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_854 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_852 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_851 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_849 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_848 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_846 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_845 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_850copy2 = function() {
	this.initialize(img.CachedBmp_850copy2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1536);


(lib.CachedBmp_843 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_842 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_840 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_839 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_837 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_836 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_835 = function() {
	this.initialize(img.CachedBmp_835);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1536);


(lib.CachedBmp_834 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_833 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_831 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_830 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_829 = function() {
	this.initialize(img.CachedBmp_829);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1536);


(lib.CachedBmp_828 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_827 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_825 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_824 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_856 = function() {
	this.initialize(img.CachedBmp_856);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1536);


(lib.CachedBmp_822 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_821 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_819 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_818 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_816 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_14"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_815 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_814 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_813 = function() {
	this.initialize(img.CachedBmp_813);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1536);


(lib.CachedBmp_812 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_811 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_889 = function() {
	this.initialize(img.CachedBmp_889);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1536);


(lib.CachedBmp_809 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_808 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_806 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_805 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_804 = function() {
	this.initialize(img.CachedBmp_804);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1531);


(lib.CachedBmp_803 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_802 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_12"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_801 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_800 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_799 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_798 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_797 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_796 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_795 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_794 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_793 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_792 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_13"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_791 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_790 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_789 = function() {
	this.initialize(img.CachedBmp_789);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1536);


(lib.CachedBmp_788 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_787 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_785 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_13"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_784 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_783 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_781 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_780 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_892 = function() {
	this.initialize(img.CachedBmp_892);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1536);


(lib.CachedBmp_778 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_13"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_777 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_776 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_774 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_773 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_771 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_770 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_769 = function() {
	this.initialize(img.CachedBmp_769);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1536);


(lib.CachedBmp_768 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_767 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_766 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_765 = function() {
	this.initialize(img.CachedBmp_765);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1536);


(lib.CachedBmp_764 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_763 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_762 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_761 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_760 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_759 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_11"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_758 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_757 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_756 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_755 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_754 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_753 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_752 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_751 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_750 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_748 = function() {
	this.initialize(img.CachedBmp_748);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,320);


(lib.CachedBmp_747 = function() {
	this.initialize(img.CachedBmp_747);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2522,237);


(lib.CachedBmp_746 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_744 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_743 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_742 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_741 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_740 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_739 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_738 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_737 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_736 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_735 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_734 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_733 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_732 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_730 = function() {
	this.initialize(img.CachedBmp_730);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,320);


(lib.CachedBmp_729 = function() {
	this.initialize(img.CachedBmp_729);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2522,179);


(lib.CachedBmp_728 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_726 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_725 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_724 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_723 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_722 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_721 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_720 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_719 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_718 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_717 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_716 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_715 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_714 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_712 = function() {
	this.initialize(img.CachedBmp_712);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,320);


(lib.CachedBmp_711 = function() {
	this.initialize(img.CachedBmp_711);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2522,179);


(lib.CachedBmp_710 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_708 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_707 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_706 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_705 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_704 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_703 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_702 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_701 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_700 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_699 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_698 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_697 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_696 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_694 = function() {
	this.initialize(img.CachedBmp_694);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,269);


(lib.CachedBmp_693 = function() {
	this.initialize(img.CachedBmp_693);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2522,179);


(lib.CachedBmp_692 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_690 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_689 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_688 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_687 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_11"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_686 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_685 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_684 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_683 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_682 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_681 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_680 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_679 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_678 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_676 = function() {
	this.initialize(img.CachedBmp_676);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,320);


(lib.CachedBmp_675 = function() {
	this.initialize(img.CachedBmp_675);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2464,237);


(lib.CachedBmp_674 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_672 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_671 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_670 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_669 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_668 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_667 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_666 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_665 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_664 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_663 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_662 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_660 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_659 = function() {
	this.initialize(img.CachedBmp_659);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,269);


(lib.CachedBmp_658 = function() {
	this.initialize(img.CachedBmp_658);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2439,179);


(lib.CachedBmp_657 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_655 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_654 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_653 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_652 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_11"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_651 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_650 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_649 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_648 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_647 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_646 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_645 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_644 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_643 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_641 = function() {
	this.initialize(img.CachedBmp_641);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,269);


(lib.CachedBmp_640 = function() {
	this.initialize(img.CachedBmp_640);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2439,179);


(lib.CachedBmp_639 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_637 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_636 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_14"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_635 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_634 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_633 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_632 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_631 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_630 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_629 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_628 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_627 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_625 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_624 = function() {
	this.initialize(img.CachedBmp_624);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,269);


(lib.CachedBmp_623 = function() {
	this.initialize(img.CachedBmp_623);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2439,179);


(lib.CachedBmp_622 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_620 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_619 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_618 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_617 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_616 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_615 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_614 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_613 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_612 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_611 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_610 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_609 = function() {
	this.initialize(img.CachedBmp_609);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2614,1162);


(lib.CachedBmp_608 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_607 = function() {
	this.initialize(img.CachedBmp_607);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,320);


(lib.CachedBmp_606 = function() {
	this.initialize(img.CachedBmp_606);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2439,179);


(lib.CachedBmp_605 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_604 = function() {
	this.initialize(img.CachedBmp_604);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2614,1129);


(lib.CachedBmp_603 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_602 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_12"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_601 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_600 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_599 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_598 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_597 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_596 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_595 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_594 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_593 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_591 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_590 = function() {
	this.initialize(img.CachedBmp_590);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,320);


(lib.CachedBmp_589 = function() {
	this.initialize(img.CachedBmp_589);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2439,179);


(lib.CachedBmp_588 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_709 = function() {
	this.initialize(img.CachedBmp_709);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2614,1129);


(lib.CachedBmp_586 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_585 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_11"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_584 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_583 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_582 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_581 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_580 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_579 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_578 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_577 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_576 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_574 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_573 = function() {
	this.initialize(img.CachedBmp_573);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,320);


(lib.CachedBmp_572 = function() {
	this.initialize(img.CachedBmp_572);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2541,179);


(lib.CachedBmp_571 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_673 = function() {
	this.initialize(img.CachedBmp_673);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2614,1129);


(lib.CachedBmp_569 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_568 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_567 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_566 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_565 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_564 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_563 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_562 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_561 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_560 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_559 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_558 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_557 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_677 = function() {
	this.initialize(img.CachedBmp_677);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2614,1159);


(lib.CachedBmp_555 = function() {
	this.initialize(img.CachedBmp_555);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,320);


(lib.CachedBmp_554 = function() {
	this.initialize(img.CachedBmp_554);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2541,179);


(lib.CachedBmp_553 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_551 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_550 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_549 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_548 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_12"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_547 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_546 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_545 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_544 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_543 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_542 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_541 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_540 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_539 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_537 = function() {
	this.initialize(img.CachedBmp_537);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,320);


(lib.CachedBmp_536 = function() {
	this.initialize(img.CachedBmp_536);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2541,120);


(lib.CachedBmp_535 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_533 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_532 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_12"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_531 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_530 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_529 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_528 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_527 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_526 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_525 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_524 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_523 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_521 = function() {
	this.initialize(img.CachedBmp_521);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,269);


(lib.CachedBmp_520 = function() {
	this.initialize(img.CachedBmp_520);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2541,179);


(lib.CachedBmp_519 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_518 = function() {
	this.initialize(img.CachedBmp_518);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2614,1138);


(lib.CachedBmp_517 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_516 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_11"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_515 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_514 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_513 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_512 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_511 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_510 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_509 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_507 = function() {
	this.initialize(img.CachedBmp_507);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,269);


(lib.CachedBmp_506 = function() {
	this.initialize(img.CachedBmp_506);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2541,179);


(lib.CachedBmp_505 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_504 = function() {
	this.initialize(img.CachedBmp_504);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2614,1135);


(lib.CachedBmp_503 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_502 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_12"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_501 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_500 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_499 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_498 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_497 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_496 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_495 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_494 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_493 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_749 = function() {
	this.initialize(img.CachedBmp_749);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2614,1159);


(lib.CachedBmp_491 = function() {
	this.initialize(img.CachedBmp_491);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,320);


(lib.CachedBmp_490 = function() {
	this.initialize(img.CachedBmp_490);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2541,179);


(lib.CachedBmp_489 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_745 = function() {
	this.initialize(img.CachedBmp_745);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2614,1129);


(lib.CachedBmp_487 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_13"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_486 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_485 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_484 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_483 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_482 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_481 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_480 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_479 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_478 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_477 = function() {
	this.initialize(img.CachedBmp_477);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2614,1179);


(lib.CachedBmp_476 = function() {
	this.initialize(img.CachedBmp_476);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2381,320);


(lib.CachedBmp_475 = function() {
	this.initialize(img.CachedBmp_475);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2541,179);


(lib.CachedBmp_474 = function() {
	this.initialize(img.CachedBmp_474);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2636,1113);


(lib.CachedBmp_898 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_897 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_896 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_911 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_910 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_909 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_908 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_907 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_906 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_905 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_904 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_903 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_902 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_901 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_900 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_899 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_895 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_50 = function() {
	this.initialize(img.CachedBmp_50);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2650,1121);


(lib.CachedBmp_49 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_48 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_47 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_46 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_44 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_42 = function() {
	this.initialize(img.CachedBmp_42);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1536);


(lib.CachedBmp_41 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(104);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(img.CachedBmp_36);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2747,1536);


(lib.CachedBmp_35 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(105);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_4"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_850 = function() {
	this.initialize(img.CachedBmp_850);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2739,1536);


(lib.CachedBmp_32 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(106);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(107);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(108);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(img.CachedBmp_28);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2653,1001);


(lib.CachedBmp_27 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(109);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(110);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(111);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(112);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(113);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(114);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(115);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_21"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(111);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(112);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(113);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(img.CachedBmp_15);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2617,992);


(lib.CachedBmp_14 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(116);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(img.CachedBmp_13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2492,924);


(lib.CachedBmp_12 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(117);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(118);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(119);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(img.CachedBmp_9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2449,503);


(lib.CachedBmp_8 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(120);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(121);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(122);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(114);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_2"]);
	this.gotoAndStop(115);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_11"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_1"]);
	this.gotoAndStop(123);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(img.CachedBmp_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2496,217);


(lib.back = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.back1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.back1_1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.back2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.back3 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.back9_1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.back9_2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.backakte = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.backbeda1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.backbeda2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.backberkas1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.backberkas2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.backbpjs1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.backbpjs2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.backdaerah1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.backdaerah2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.backdomi1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.backdomi2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.backdtks1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.backdtks2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.backkematian1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.backkematian2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.backketmati1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.backketmati2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.backkia1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.backkia2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.backktp1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_9"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.backktp2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.backnikah1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.backnikah2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.backskck2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.backsktm1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.backsktm2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.backsku1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.backsku2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.BGweb = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_21"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.btnBack = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.BukuNikah = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.DesainlogountukAk = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_20"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Desainlogountukcetakfoto = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_19"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.DesainlogountukPBB = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_18"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Fotousaha = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_17"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.home = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.home1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.home1_1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.home2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.home3 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.home9_1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.home9_2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.homeakte = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.homebeda1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.homebeda2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.homeberkas1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.homeberkas2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.homebpjs1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.homebpjs2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.homedaerah1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.homedaerah2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.homedomi1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.homedomi2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.homedtks1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_7"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.homedtks2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.homekematian1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.homekematian2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.homeketmati1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.homeketmati2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.homekia1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.homekia2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.homektp1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.homektp2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.homenikah1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.homenikah2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.homeskck1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.homeskck2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.homesktm1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.homesktm2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.homesku1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_6"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.info1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.info2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.KartuKeluarga = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_11"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.KTP = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_10"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.logoberbentuksurat = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_16"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.LogoKota = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_20"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.loket1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.loket2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.materai10ribu = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_15"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.PendaftaranLoket = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_11"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.RiwayatLoket = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_11"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.riwayat1 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.riwayat2 = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.suratrtrw = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_14"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.tombolinfo = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.tombollayanan = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_8"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.tombolloket = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_5"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.vecteezy_facebooklogopngfacebookicontransparentpng_18930698 = function() {
	this.initialize(img.vecteezy_facebooklogopngfacebookicontransparentpng_18930698);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3008,2997);


(lib.vecteezy_instagramlogopnginstagramicontransparent_18930415 = function() {
	this.initialize(img.vecteezy_instagramlogopnginstagramicontransparent_18930415);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2987,2987);


(lib.whatsapp = function() {
	this.initialize(ss["Edukasi Pelayanan Publik _Terbaru__atlas_3"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whatsA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.whatsapp();
	this.instance.setTransform(0,0,0.2451,0.2629);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whatsA, new cjs.Rectangle(0,0,62.8,67.3), null);


(lib.tombolloket_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.tombolloket();
	this.instance.setTransform(0,0,0.211,0.2398);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tombolloket_1, new cjs.Rectangle(0,0,100,100), null);


(lib.tombollayanan_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.tombollayanan();
	this.instance.setTransform(0,0,0.2028,0.2242);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tombollayanan_1, new cjs.Rectangle(0,0,100,100), null);


(lib.tombolkk = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.tombolkembali = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.back();
	this.instance.setTransform(0,0,0.0744,0.0723);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tombolkembali, new cjs.Rectangle(0,0,34.9,35.2), null);


(lib.tombolinfo_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.tombolinfo();
	this.instance.setTransform(0,0,0.1996,0.2336);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tombolinfo_1, new cjs.Rectangle(0,0,100,100), null);


(lib.tombolhome = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.home();
	this.instance.setTransform(0,0,0.108,0.1038);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tombolhome, new cjs.Rectangle(0,0,49.7,48.9), null);


(lib.logokota1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.LogoKota();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logokota1, new cjs.Rectangle(0,0,1280,853), null);


(lib.Insta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.vecteezy_instagramlogopnginstagramicontransparent_18930415();
	this.instance.setTransform(0,0,0.021,0.0225);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Insta, new cjs.Rectangle(0,0,62.8,67.3), null);


(lib.homesktm1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homesktm1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.homesktm1_1, new cjs.Rectangle(0,0,88,88), null);


(lib.homeloket = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.loket2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.homeloket, new cjs.Rectangle(0,0,88,88), null);


(lib.homeInfo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.info2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.homeInfo, new cjs.Rectangle(0,0,460,471), null);


(lib.home3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.home3();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.home3_1, new cjs.Rectangle(0,0,460,471), null);


(lib.Fb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.vecteezy_facebooklogopngfacebookicontransparentpng_18930698();
	this.instance.setTransform(0,0,0.0209,0.0225);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Fb, new cjs.Rectangle(0,0,62.8,67.3), null);


(lib.btnYa17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa17, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa16, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa15, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa14, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa13, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa12, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa11, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa10, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa9, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa8, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa7, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa6, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa5, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa4, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa3, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa2, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnYa1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#336600").s().p("ArvCsIAAlXIXfAAIAAFXg");
	this.shape.setTransform(75.175,17.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnYa1, new cjs.Rectangle(0,0,150.4,34.5), null);


(lib.btnWeb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A0WDBIAAmBMAotAAAIAAGBg");
	this.shape.setTransform(130.325,19.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnWeb, new cjs.Rectangle(0,0,260.7,38.7), null);


(lib.btnTlp = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A0WDDIAAmFMAotAAAIAAGFg");
	this.shape.setTransform(130.275,19.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTlp, new cjs.Rectangle(0,0,260.6,39), null);


(lib.btnTidak17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak17, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak16, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak15, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak14, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak13, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak12, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak11, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak10, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak9, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak8, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak7, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak6, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak5, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak4, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak3, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ApAC0IAAlnISAAAIAAFng");
	this.shape.setTransform(57.65,18);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak2, new cjs.Rectangle(0,0,115.3,36), null);


(lib.btnTidak1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AsZC8IAAl3IYzAAIAAF3g");
	this.shape.setTransform(79.375,18.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnTidak1, new cjs.Rectangle(0,0,158.8,37.6), null);


(lib.btnSubmit = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#009900").s().p("ApLDlIAAnKISXAAIAAHKg");
	this.shape.setTransform(58.8,22.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnSubmit, new cjs.Rectangle(0,0,117.6,45.9), null);


(lib.btnsku = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnsku, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnsktm = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnsktm, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnskm = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnskm, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnskck = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnskck, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnriwayat = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.RiwayatLoket();
	this.instance.setTransform(0,0,0.2762,0.2551);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnriwayat, new cjs.Rectangle(0,0,152.2,169.2), null);


(lib.btnPrev = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AliDUIAAmnILFAAIAAGngAiKADIC1CHIAAkZg");
	this.shape.setTransform(35.5,21.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnPrev, new cjs.Rectangle(0,0,71,42.4), null);


(lib.btnpindahkk = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnpindahkk, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnpendaftaran = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.PendaftaranLoket();
	this.instance.setTransform(0,0,0.2642,0.2647);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnpendaftaran, new cjs.Rectangle(0,0,152.2,169.2), null);


(lib.btnnikah = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnikah, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnnext17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext17, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext16, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext15, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext14, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext13, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext12, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext11, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext10, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext9, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext8, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext7, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext6, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext5, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext4, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext3, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext2, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnnext1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AslDpIAAnRIZLAAIAAHRg");
	this.shape.setTransform(80.575,23.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnnext1, new cjs.Rectangle(0,0,161.2,46.5), null);


(lib.btnNext = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AliDUIAAmnILFAAIAAGngAgkCAICliKIiliDg");
	this.shape.setTransform(35.5,21.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnNext, new cjs.Rectangle(0,0,71,42.4), null);


(lib.btnkk = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnkk, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnkia = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnkia, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnkematian = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnkematian, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnkelahiran = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnkelahiran, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnhomesku2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homesku1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomesku2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomeskck = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homeskck1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomeskck, new cjs.Rectangle(0,0,88,88), null);


(lib.btnHomeR = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.riwayat2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnHomeR, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomenikah2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homenikah2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomenikah2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomenikah1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homenikah1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomenikah1, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomemati2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homekematian2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomemati2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomemati1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homekematian1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomemati1, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomektp2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homektp2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomektp2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomektp1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homektp1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomektp1, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomekia2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homekia2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomekia2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomekia1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homekia1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomekia1, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomekeke2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homeketmati2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomekeke2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomekeke = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homeketmati1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomekeke, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomedtks = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homedtks1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomedtks, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomedom = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homedomi2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomedom, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomedaerah = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homedaerah1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomedaerah, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomebpjs = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homebpjs2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomebpjs, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomeberkas = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homeberkas1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomeberkas, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhomebeda = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homebeda1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomebeda, new cjs.Rectangle(0,0,460,471), null);


(lib.btnhomeakta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homeakte();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhomeakta, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homebeda2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome17, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homeberkas2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome16, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homeskck2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome15, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homedtks2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome14, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homedaerah2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome13, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homebpjs1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome12, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homedomi1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome11, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.homesktm2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome10, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome9_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.home9_2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome9_1, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.home9_1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome9, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.home2();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome3, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.home1_1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome2_2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnhome2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.home1();
	this.instance.setTransform(0,0,0.1913,0.1868);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnEmail = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A0YDDIAAmFMAoxAAAIAAGFg");
	this.shape.setTransform(130.5,19.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnEmail, new cjs.Rectangle(0,0,261,39), null);


(lib.btndtks = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btndtks, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btndomisili = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btndomisili, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnbpjs = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbpjs, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnberkas = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnberkas, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnbelumnikah = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbelumnikah, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnbeda = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#252525").ss(1,1,1).p("A3ekcMAu9AAAIAAI5Mgu9AAAg");
	this.shape.setTransform(150.3,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#33CC99").s().p("A3eEdIAAo5MAu9AAAIAAI5g");
	this.shape_1.setTransform(150.3,28.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbeda, new cjs.Rectangle(-1,-1,302.6,59), null);


(lib.btnBatal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("Ap4DmIAAnLITxAAIAAHLg");
	this.shape.setTransform(63.325,23);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnBatal, new cjs.Rectangle(0,0,126.7,46), null);


(lib.btnbacksku2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backsku2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbacksku2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackskck = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backskck2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackskck, new cjs.Rectangle(0,0,88,88), null);


(lib.btnBackR = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.riwayat1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnBackR, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbacknikah2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backnikah2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbacknikah2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbacknikah1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backnikah1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbacknikah1, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackmati2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backkematian2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackmati2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackmati1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backkematian1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackmati1, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackktp2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backktp2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackktp2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackktp1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backktp1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackktp1, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackkia2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backkia2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackkia2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackkia1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backkia1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackkia1, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackkeke2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backketmati2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackkeke2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackkeke = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backketmati1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackkeke, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackdtks = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backdtks1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackdtks, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackdom = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backdomi2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackdom, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackdaerah = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backdaerah1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackdaerah, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackbpjs = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backbpjs2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackbpjs, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackberkas = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backberkas1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackberkas, new cjs.Rectangle(0,0,88,88), null);


(lib.btnbackbeda = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backbeda1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackbeda, new cjs.Rectangle(0,0,469,487), null);


(lib.btnbackakta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backakte();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnbackakta, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backbeda2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback17, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backberkas2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback16, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backskck2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback15, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backdtks2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback14, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backdaerah2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback13, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backbpjs1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback12, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backdomi1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback11, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backsktm2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback10, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback9_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.back9_2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback9_1, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.back9_1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback9, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backsku1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback6, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.back2();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback3, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.back1_1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback2_2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnback2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.back1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnback2, new cjs.Rectangle(0,0,88,88), null);


(lib.btnBack_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.btnBack();
	this.instance.setTransform(0,0,0.1462,0.1456);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnBack_1, new cjs.Rectangle(0,0,68.6,70.9), null);


(lib.backsktm1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.backsktm1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backsktm1_1, new cjs.Rectangle(0,0,88,88), null);


(lib.backloket1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.loket1();
	this.instance.setTransform(0,0,0.1876,0.1807);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backloket1, new cjs.Rectangle(0,0,88,88), null);


(lib.backInfo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.info1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backInfo, new cjs.Rectangle(0,0,469,487), null);


(lib.back3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.back3();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.back3_1, new cjs.Rectangle(0,0,469,487), null);


(lib.btnktp = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btnktp = new lib.btnpindahkk();
	this.btnktp.name = "btnktp";
	this.btnktp.setTransform(150.3,28.5,1,1,0,0,0,150.3,28.5);

	this.timeline.addTween(cjs.Tween.get(this.btnktp).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnktp, new cjs.Rectangle(-0.5,-0.5,301.6,58), null);


(lib.btnhome6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.btnhome3 = new lib.btnhome3();
	this.btnhome3.name = "btnhome3";
	this.btnhome3.setTransform(44,44,1,1,0,0,0,44,44);

	this.timeline.addTween(cjs.Tween.get(this.btnhome3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btnhome6, new cjs.Rectangle(0,0,88,88), null);


// stage content:
(lib.EdukasiPelayananPublikTerbaru = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {halamanloket:19,halamandaftar:22,riwayatloket:27,buktiPendaftaran:32,halamaninfo:37,halamanutama:0,halamanlayanan:4,halamankk:9,halamankklanjutan:11,halamanlahir:40,halamanlahirlanjutan:43,halamanktp:45,halamanktplanjutan:48,halamankia:50,halamankialanjutan:53,halamankematian:55,halamankematianlanjutan:58,halamansku:60,halamanskulanjutan:63,halamanketmati:65,halamanketmatianlanjutan:68,halamannikah:70,halamannikahlanjutan:73,halamanbelumnikah:75,halamanbelumnikahlanjutan:78,halamansktm:80,halamansktmlanjutan:83,halamansdts:85,halamansdtslanjutan:88,halamanbpjs:90,halamanbpjslanjutan:93,halamanpindah:95,halamanpindahlanjutan:98,halamandtks:100,halamandtkslanjutan:103,halamanskck:105,halamanskcklanjutan:108,halamanberkas:110,halamanberkaslanjutan:113,halamannama:115,halamannamalanjutan:118};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,4,9,11,19,22,27,32,37,40,43,45,48,50,53,55,58,60,63,65,68,70,73,75,78,80,83,85,88,90,93,95,98,100,103,105,108,110,113,115,118];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		
		this.whatsA.buttonMode = true;
		this.whatsA.mouseChildren = false; 
		
		this.whatsA.addEventListener("click", function(evt) {
		    window.open("https://api.whatsapp.com/send?phone=6282112721958");
		});
		this.stop();
		
		this.instag.buttonMode = true;
		this.instag.mouseChildren = false; 
		
		this.instag.addEventListener("click", function(evt) {
		    window.open("https://www.instagram.com/kelurahan_jatikramat/", "_blank");
		});
		this.stop();
		
		this.faceb.buttonMode = true;
		this.faceb.mouseChildren = false; 
		
		this.faceb.addEventListener("click", function(evt) {
		    window.open("https://web.facebook.com/p/kelurahan_jatikramat-100089312626284/?_rdc=1&_rdr#", "_blank");
		});
		this.stop(); // Hentikan timeline di frame 1
		
		// Pastikan btnlayanan, btnloket, btninfo semuanya ada di stage frame 1
		this.btnlayanan.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnloket.addEventListener("click", function() {
		    this.gotoAndStop("halamanloket");
		}.bind(this));
		
		this.btninfo.addEventListener("click", function() {
		    this.gotoAndStop("halamaninfo");
		}.bind(this));
		
		if (exportRoot.containerRiwayat) {
		  exportRoot.removeChild(exportRoot.containerRiwayat);
		  exportRoot.containerRiwayat = null;
		}
	}
	this.frame_4 = function() {
		this.stop(); // supaya tidak autoplay ke frame berikutnya
		
		this.btnhome.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnkembali.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		//tombol layanan
		
		this.btnkk.addEventListener("click", function() {
		    this.gotoAndStop("halamankk");
		}.bind(this));
		
		this.btnkelahiran.addEventListener("click", function() {
		    this.gotoAndStop("halamanlahir");
		}.bind(this));
		
		this.btnkematian.addEventListener("click", function() {
		    this.gotoAndStop("halamankematian");
		}.bind(this));
		
		this.btnktp.addEventListener("click", function() {
		    this.gotoAndStop("halamanktp");
		}.bind(this));
		
		this.btnkia.addEventListener("click", function() {
		    this.gotoAndStop("halamankia");
		}.bind(this));
		
		this.btnsku.addEventListener("click", function() {
		    this.gotoAndStop("halamansku");
		}.bind(this));
		
		this.btnskm.addEventListener("click", function() {
		    this.gotoAndStop("halamanketmati");
		}.bind(this));
		
		this.btnnikah.addEventListener("click", function() {
		    this.gotoAndStop("halamannikah");
		}.bind(this));
		
		this.btnbelumnikah.addEventListener("click", function() {
		    this.gotoAndStop("halamanbelumnikah");
		}.bind(this));
		
		this.btnsktm.addEventListener("click", function() {
		    this.gotoAndStop("halamansktm");
		}.bind(this));
		
		this.btndomisili.addEventListener("click", function() {
		    this.gotoAndStop("halamansdts");
		}.bind(this));
		
		this.btnbpjs.addEventListener("click", function() {
		    this.gotoAndStop("halamanbpjs");
		}.bind(this));
		
		this.btnpindahkk.addEventListener("click", function() {
		    this.gotoAndStop("halamanpindah");
		}.bind(this));
		
		this.btndtks.addEventListener("click", function() {
		    this.gotoAndStop("halamandtks");
		}.bind(this));
		
		this.btnberkas.addEventListener("click", function() {
		    this.gotoAndStop("halamanberkas");
		}.bind(this));
		
		this.btnskck.addEventListener("click", function() {
		    this.gotoAndStop("halamanskck");
		}.bind(this));
		
		this.btnbeda.addEventListener("click", function() {
		    this.gotoAndStop("halamannama");
		}.bind(this));
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
		
		this.btnhome2.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback2.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext1.addEventListener("click", function() {
		    this.gotoAndStop("halamankklanjutan");
		}.bind(this));
		this.stop();
		
		this.btnhome1.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback1.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
	}
	this.frame_11 = function() {
		this.stop();
		
		this.btnTidak1.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa1.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop();
		
		this.btnhome2_2.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback2_2.addEventListener("click", function() {
		    this.gotoAndStop("halamankk");
		}.bind(this));
	}
	this.frame_19 = function() {
		this.stop();
		
		this.btnpendaftaran.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		
		this.btnriwayat.addEventListener("click", function() {
		    this.gotoAndStop("riwayatloket");
		}.bind(this));
		
		if (exportRoot.containerRiwayat) {
		  exportRoot.removeChild(exportRoot.containerRiwayat);
		  exportRoot.containerRiwayat = null;
		}
		
		this.homeloket1.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.backloket1.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		this.stop();
	}
	this.frame_22 = function() {
		this.stop();
		
		// 🔧 Fungsi presisi posisi input terhadap canvas Animate
		function createInputOnCanvas(id, placeholder, x, y) {
		  window.requestAnimationFrame(() => {
		    const canvas = document.getElementsByTagName("canvas")[0];
		    const bounds = canvas.getBoundingClientRect();
		    const offsetX = bounds.left + window.scrollX;
		    const offsetY = bounds.top + window.scrollY;
		
		    const input = document.createElement("input");
		    input.type = "text";
		    input.placeholder = placeholder;
		    input.id = id;
		
		    Object.assign(input.style, {
		      position: "absolute",
		      left: offsetX + x + "px",
		      top: offsetY + y + "px",
		      width: "370px",
		      height: "40px",
		      fontSize: "16px",
		      border: "1px solid #ccc",
		      borderRadius: "6px",
		      padding: "6px 10px",
		      boxSizing: "border-box",
		      zIndex: 1000
		    });
		
		    document.body.appendChild(input);
		  });
		}
		
		// 📌 Panggil input di posisi yang telah disesuaikan
		createInputOnCanvas("namaInput", "Nama Lengkap", 85, 350);
		createInputOnCanvas("emailInput", "Email", 85, 450);
		createInputOnCanvas("layananInput", "Layanan Pengajuan", 85, 550);
		
		// 🕒 Tampilkan tanggal otomatis
		const now = new Date();
		this.txtTanggal.text = now.toLocaleDateString("id-ID");
		
		// 🔙 Tombol batal
		this.btnBatal.addEventListener("click", function () {
		  ["namaInput", "emailInput", "layananInput"].forEach(id => {
		    const el = document.getElementById(id);
		    if (el) el.remove();
		  });
		  this.gotoAndStop("halamanloket");
		}.bind(this));
		
		// 🧠 Listener tombol submit (dipasang saat tombol muncul)
		const cekTombol = createjs.Ticker.on("tick", () => {
		  if (this.btnSubmit) {
		    this.btnSubmit.addEventListener("click", () => {
		      const nama = document.getElementById("namaInput").value.trim();
		      const email = document.getElementById("emailInput").value.trim();
		      const layanan = document.getElementById("layananInput").value.trim();
		
		      if (!nama || !email || !layanan) {
		        alert("⚠️ Mohon lengkapi semua kolom.");
		        return;
		      }
		
		      // 🕒 Validasi waktu akses pendaftaran (16.00 – 23.00 WIB)
				const waktu = new Date();
				const jam = waktu.getHours();
				const menit = waktu.getMinutes();
				const totalMenit = jam * 60 + menit;
		
				const buka = 960;   // 16.00 WIB (16 * 60)
				const tutup = 1380; // 23.00 WIB (23 * 60)
		
				if (totalMenit < buka || totalMenit > tutup) {
				alert("⏰ Maaf, pendaftaran hanya dibuka pukul 16.00 – 23.00 WIB.");
				return;
				}
		
		
		      const hariIni = waktu.toLocaleDateString("id-ID");
		      if (hariIni !== exportRoot.tanggalTerakhir) {
		        exportRoot.antrianTerakhir = 0;
		        exportRoot.daftarRiwayat = [];
		        exportRoot.tanggalTerakhir = hariIni;
		      }
		
		      if (typeof exportRoot.antrianTerakhir !== "number") {
		        exportRoot.antrianTerakhir = 0;
		      }
		
		      if (exportRoot.antrianTerakhir >= 100) {
		        alert("🚫 Pendaftaran sudah penuh hari ini.");
		        return;
		      }
		
		      exportRoot.antrianTerakhir += 1;
		      const nomorAntri = exportRoot.antrianTerakhir.toString();
		      const noLoket = Math.floor(Math.random() * 4) + 1;
		
		      exportRoot.dataPendaftaran = {
		        nama,
		        email,
		        layanan,
		        tanggal: hariIni,
		        nomorAntri,
		        noLoket
		      };
		
		      if (!exportRoot.daftarRiwayat) exportRoot.daftarRiwayat = [];
		      exportRoot.daftarRiwayat.push({
		        nama,
		        layanan,
		        tanggal: hariIni,
		        bukti: { ...exportRoot.dataPendaftaran },
		        baru: true
		      });
		
		      ["namaInput", "emailInput", "layananInput"].forEach(id => {
		        const el = document.getElementById(id);
		        if (el) el.remove();
		      });
		
		      this.gotoAndStop("buktiPendaftaran");
		    });
		
		    createjs.Ticker.off("tick", cekTombol);
		  }
		});
		this.stop();
		
		// 🔙 Tombol Home
		this.home3.addEventListener("click", function () {
		  ["namaInput", "emailInput", "layananInput"].forEach(id => {
		    const el = document.getElementById(id);
		    if (el) el.remove();
		  });
		  this.gotoAndStop("halamanutama");
		}.bind(this));
		
		// 🔄 Tombol Kembali ke Loket Daring
		this.back3.addEventListener("click", function () {
		  ["namaInput", "emailInput", "layananInput"].forEach(id => {
		    const el = document.getElementById(id);
		    if (el) el.remove();
		  });
		  this.gotoAndStop("halamanloket");
		}.bind(this));
		this.stop();
	}
	this.frame_27 = function() {
		this.stop();
		
		// 🏠 Tombol Home
		this.btnHomeR.buttonMode = true;
		this.btnHomeR.addEventListener("click", () => {
		  bersihkanRiwayatVisual(); // pastikan riwayat dihapus dari layar
		  exportRoot.gotoAndStop("halamanutama"); // pindah ke halaman utama
		});
		
		// 🔙 Tombol Back
		this.btnBackR.buttonMode = true;
		this.btnBackR.addEventListener("click", () => {
		  bersihkanRiwayatVisual(); // hapus daftar riwayat sebelum pindah
		  exportRoot.gotoAndStop("halamanloket"); // kembali ke halaman loket awal
		});
		
		function bersihkanRiwayatVisual() {
		  if (exportRoot.containerRiwayat) {
		    exportRoot.removeChild(exportRoot.containerRiwayat);
		    exportRoot.containerRiwayat = null;
		  }
		}
		this.stop();
		
		// ✅ Tampilkan ulang daftar saat masuk ke frame ini
		if (!exportRoot.tanggalTerakhir) exportRoot.tanggalTerakhir = new Date().toLocaleDateString("id-ID");
		
		// 🔄 Ambil data riwayat hari ini
		const tanggalSekarang = new Date().toLocaleDateString("id-ID");
		const daftar = (exportRoot.daftarRiwayat || []).filter(item => item.tanggal === tanggalSekarang);
		
		// 🧼 Hapus container sebelumnya jika ada
		if (exportRoot.containerRiwayat) {
		  exportRoot.removeChild(exportRoot.containerRiwayat);
		}
		exportRoot.containerRiwayat = new createjs.Container();
		exportRoot.addChild(exportRoot.containerRiwayat);
		
		// 📄 Setup pagination
		const jumlahPerHalaman = 10;
		const totalHalaman = Math.ceil(daftar.length / jumlahPerHalaman);
		exportRoot.riwayatHalaman = exportRoot.riwayatHalaman || 1;
		
		// 🎨 Fungsi tampil card riwayat
		function tampilkanHalamanRiwayat() {
		  exportRoot.containerRiwayat.removeAllChildren();
		
		  const awal = (exportRoot.riwayatHalaman - 1) * jumlahPerHalaman;
		  const akhir = Math.min(awal + jumlahPerHalaman, daftar.length);
		
		  const yStart = 250;
		  const jarakY = 90;
		
		  if (daftar.length === 0) {
		    const kosong = new createjs.Text("⚠️ Belum ada pendaftar hari ini", "italic 18px Arial", "#999");
		    kosong.textAlign = "center";
		    kosong.x = 480;
		    kosong.y = yStart;
		    exportRoot.containerRiwayat.addChild(kosong);
		    return;
		  }
		
		  for (let i = awal; i < akhir; i++) {
		    const item = daftar[i];
		    const yPos = yStart + (i - awal) * jarakY;
		
		    // 🟫 Card background
		    const card = new createjs.Shape();
		    card.graphics.beginFill("#ffffff").setStrokeStyle(1).beginStroke("#cccccc")
		      .drawRoundRect(60, yPos, 500, 80, 10);
		
		    // 📝 Info pendaftar
		    const teksInfo = new createjs.Text(
		      `${item.nomorAntri || i + 1}. ${item.nama} - ${item.layanan}`,
		      "bold 16px Arial", "#000"
		    );
		    teksInfo.x = 70;
		    teksInfo.y = yPos + 12;
		
		    // 📅 Tanggal
		    const teksTanggal = new createjs.Text(`📅 ${item.tanggal}`, "14px Arial", "#555");
		    teksTanggal.x = 60;
		    teksTanggal.y = yPos + 42;
		
		    // 📄 Tombol Detail
		    const btnDetail = new createjs.Text("📄 Detail", "bold 14px Arial", "#0077cc");
		    btnDetail.x = 470;
		    btnDetail.y = yPos + 30;
		    btnDetail.cursor = "pointer";
		
		    btnDetail.addEventListener("click", () => {
		      bersihkanRiwayatVisual();
		      exportRoot.dataPendaftaran = item.bukti;
		      exportRoot.gotoAndStop("buktiPendaftaran");
		    });
		
		    exportRoot.containerRiwayat.addChild(card, teksInfo, teksTanggal, btnDetail);
		  }
		
		  exportRoot.txtHalaman.text = `Halaman ${exportRoot.riwayatHalaman} dari ${totalHalaman || 1}`;
		}
		
		// 🔘 Navigasi halaman
		this.btnNext.addEventListener("click", () => {
		  if (exportRoot.riwayatHalaman < totalHalaman) {
		    exportRoot.riwayatHalaman++;
		    tampilkanHalamanRiwayat();
		  }
		});
		
		this.btnPrev.addEventListener("click", () => {
		  if (exportRoot.riwayatHalaman > 1) {
		    exportRoot.riwayatHalaman--;
		    tampilkanHalamanRiwayat();
		  }
		});
		
		// 🟨 Popup antrian terbaru
		const last = daftar[daftar.length - 1];
		if (last && last.baru) {
		  const cardX = 30, cardY = 160, cardW = 320, cardH = 80;
		
		  const bg = new createjs.Shape();
		  bg.graphics.beginFill("#fff3cd").drawRoundRect(cardX, cardY, cardW, cardH, 8);
		
		  const teksJudul = new createjs.Text("📢 Antrian Terbaru:", "bold 15px Arial", "#856404");
		  teksJudul.x = cardX + 10;
		  teksJudul.y = cardY + 8;
		
		  const teksLayanan = new createjs.Text(last.layanan, "16px Arial", "#000");
		  teksLayanan.x = cardX + 10;
		  teksLayanan.y = cardY + 32;
		
		  const teksTanggal = new createjs.Text(`Tanggal: ${last.tanggal}`, "14px Arial", "#000");
		  teksTanggal.x = cardX + 10;
		  teksTanggal.y = cardY + 54;
		
		  const tombolKlik = new createjs.Text("Lihat Detail", "bold 14px Arial", "#0056b3");
		  tombolKlik.x = cardX + cardW - 100;
		  tombolKlik.y = cardY + 50;
		  tombolKlik.cursor = "pointer";
		
		  tombolKlik.addEventListener("click", () => {
		    bersihkanRiwayatVisual();
		    exportRoot.dataPendaftaran = last.bukti;
		    exportRoot.gotoAndStop("buktiPendaftaran");
		  });
		
		  [bg, teksJudul, teksLayanan, teksTanggal, tombolKlik].forEach(el => {
		    exportRoot.containerRiwayat.addChild(el);
		  });
		
		  last.baru = false;
		}
		
		// 🚀 Tampilkan riwayat awal
		tampilkanHalamanRiwayat();
		
		// 🧹 Bersihkan visual saat pindah frame
		function bersihkanRiwayatVisual() {
		  if (exportRoot.containerRiwayat) {
		    exportRoot.removeChild(exportRoot.containerRiwayat);
		    exportRoot.containerRiwayat = null;
		  }
		}
		this.stop();
		
		// ✅ Tombol navigasi Home & Back
		setTimeout(() => {
		  if (this.btnHomeR) {
		    this.btnHomeR.buttonMode = true;
		    this.btnHomeR.addEventListener("click", () => {
		      bersihkanRiwayatVisual();
		      exportRoot.gotoAndStop("halamanutama");
		    });
		  }
		
		  if (this.btnBackR) {
		    this.btnBackR.buttonMode = true;
		    this.btnBackR.addEventListener("click", () => {
		      bersihkanRiwayatVisual();
		      exportRoot.gotoAndStop("halamanloket");
		    });
		  }
		}, 400); // beri jeda render agar tombol tersedia
		this.stop();
		
		// 🧼 Fungsi untuk membersihkan riwayat visual
		function bersihkanRiwayatVisual() {
		  if (exportRoot.teksRiwayatList) {
		    exportRoot.teksRiwayatList.forEach(el => exportRoot.removeChild(el));
		    exportRoot.teksRiwayatList = [];
		  }
		  const kosong = exportRoot.getChildByName("pesanKosong");
		  if (kosong) exportRoot.removeChild(kosong);
		}
		
		// ✅ Pastikan tombol aktif sebagai MovieClip yang bisa diklik
		this.btnHomeR.buttonMode = true;
		this.btnBackR.buttonMode = true;
		
		// ✅ Pastikan tombol berada di lapisan atas
		exportRoot.setChildIndex(this.btnHomeR, exportRoot.numChildren - 1);
		exportRoot.setChildIndex(this.btnBackR, exportRoot.numChildren - 1);
		
		// 🟢 Event tombol Home
		this.btnHomeR.addEventListener("click", () => {
		  bersihkanRiwayatVisual(); // bersihkan tampilan riwayat
		  exportRoot.gotoAndStop("halamanutama");
		});
		
		// 🔙 Event tombol Back
		this.btnBackR.addEventListener("click", () => {
		  bersihkanRiwayatVisual(); // bersihkan tampilan riwayat
		  exportRoot.gotoAndStop("halamanloket");
		});
	}
	this.frame_32 = function() {
		this.stop();
		
		// 🔄 Ambil data yang disimpan saat pendaftaran
		const data = exportRoot.dataPendaftaran;
		
		// ✅ Tampilkan ke elemen text field di panggung
		this.txtNama.text = data.nama;
		this.txtEmail.text = data.email;
		this.txtLayanan.text = data.layanan;
		this.txtNoAntrian.text = data.nomorAntri;
		this.txtNoLoket.text = data.noLoket;
		this.txtTanggal.text = data.tanggal;
		
		// 📋 Log data ke console (opsional untuk debugging)
		console.log("📦 Data Bukti:", data);
		
		// 🔙 Tombol kembali ke halaman utama
		this.btnBack.addEventListener("click", function() {
		  this.gotoAndStop("halamanutama");
		}.bind(this));
		
		if (exportRoot.containerRiwayat) {
		  exportRoot.removeChild(exportRoot.containerRiwayat);
		  exportRoot.containerRiwayat = null;
		}
	}
	this.frame_37 = function() {
		this.stop();
		
		// 🧹 Bersihkan maps kalau ada sisa dari frame sebelumnya
		const iframe = document.getElementById("mapsLokasi");
		if (iframe) iframe.remove();
		
		// ☎️ Tombol Telepon
		this.btnTlp.buttonMode = true;
		this.btnTlp.addEventListener("click", () => {
		  window.location.href = "https://api.whatsapp.com/send?text=Kantor%20Kelurahan%20Jatikramat%0A%0A%20https%3A%2F%2Fg.co%2Fkgs%2Fxiqdyhr";
		});
		
		// ✉️ Tombol Email
		this.btnEmail.buttonMode = true;
		this.btnEmail.addEventListener("click", () => {
		  window.location.href = "mailto:Kel.jatikramat@gmail.com";
		});
		
		// 🌐 Tombol Website
		this.btnWeb.buttonMode = true;
		this.btnWeb.addEventListener("click", () => {
		  window.open("https://kel-jatikramat.bekasikota.go.id/home", "_blank");
		});
		
		// 🗺️ Fungsi Maps Embed
		function tampilkanMapsLokasi() {
		  window.requestAnimationFrame(() => {
		    const canvas = document.getElementsByTagName("canvas")[0];
		    const bounds = canvas.getBoundingClientRect();
		    const offsetX = bounds.left + window.scrollX;
		    const offsetY = bounds.top + window.scrollY;
		
		    const iframe = document.createElement("iframe");
		    iframe.src = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.892295040893!2d106.94441820989599!3d-6.277888793684697!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e698d6d8a7db54f%3A0x5ad8bdfec56824f3!2sKantor%20Kelurahan%20Jatikramat!5e0!3m2!1sid!2sid!4v1751625559416!5m2!1sid!2sid"; 
		    iframe.width = "500";
		    iframe.height = "300";
		
		    Object.assign(iframe.style, {
		      position: "absolute",
		      left: offsetX + 450 + "px",
		      top: offsetY + 400 + "px",
		      border: "0",
		      borderRadius: "10px",
		      boxShadow: "0 0 10px rgba(0,0,0,0.2)",
		      zIndex: 1000,
		      pointerEvents: "none" // ✅ biar gak nutupi tombol
		    });
		
		    iframe.id = "mapsLokasi";
		    document.body.appendChild(iframe);
		  });
		}
		
		tampilkanMapsLokasi(); // ✅ Tampilkan otomatis saat frame aktif
		
		// 🔙 Tombol HOME
		this.homeInfo.buttonMode = true;
		this.homeInfo.addEventListener("click", function () {
		  const iframe = document.getElementById("mapsLokasi");
		  if (iframe) iframe.remove(); // 🧹 hapus iframe agar tidak looping
		  this.gotoAndStop("halamanutama");
		}.bind(this));
		
		// 🔙 Tombol BACK
		this.backInfo.buttonMode = true;
		this.backInfo.addEventListener("click", function () {
		  const iframe = document.getElementById("mapsLokasi");
		  if (iframe) iframe.remove();
		  this.gotoAndStop("halamanutama");
		}.bind(this));
	}
	this.frame_40 = function() {
		this.stop();
		
		this.btnhome3.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback3.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext2.addEventListener("click", function() {
		    this.gotoAndStop("halamanlahirlanjutan");
		}.bind(this));
		this.stop();
	}
	this.frame_43 = function() {
		this.stop();
		
		this.btnTidak2.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa2.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop();
		
		this.btnhomeakta.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackakta.addEventListener("click", function() {
		    this.gotoAndStop("halamankelahiran");
		}.bind(this));
	}
	this.frame_45 = function() {
		this.stop();
		
		this.btnhomektp1.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackktp1.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext3.addEventListener("click", function() {
		    this.gotoAndStop("halamanktplanjutan");
		}.bind(this));
		this.stop();
	}
	this.frame_48 = function() {
		this.stop();
		
		this.btnTidak3.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa3.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop();
		
		this.btnhomektp2.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackktp2.addEventListener("click", function() {
		    this.gotoAndStop("halamanktp");
		}.bind(this));
	}
	this.frame_50 = function() {
		this.stop();
		
		this.btnhomekia1.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackkia1.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext4.addEventListener("click", function() {
		    this.gotoAndStop("halamankialanjutan");
		}.bind(this));
		this.stop();
	}
	this.frame_53 = function() {
		this.stop();
		
		this.btnTidak4.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa4.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop();
		
		this.btnhomekia2.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackkia2.addEventListener("click", function() {
		    this.gotoAndStop("halamankia");
		}.bind(this));
	}
	this.frame_55 = function() {
		this.stop();
		
		this.btnhomemati1.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackmati1.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext5.addEventListener("click", function() {
		    this.gotoAndStop("halamankematianlanjutan");
		}.bind(this));
		this.stop();
	}
	this.frame_58 = function() {
		this.stop();
		
		this.btnTidak5.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa5.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop();
		
		this.btnhomemati2.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackmati2.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
	}
	this.frame_60 = function() {
		this.stop();
		
		this.btnhome6.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback6.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext6.addEventListener("click", function() {
		    this.gotoAndStop("halamanskulanjutan");
		}.bind(this));
	}
	this.frame_63 = function() {
		this.stop();
		
		this.btnTidak6.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa6.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		
		this.btnhomesku2.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbacksku2.addEventListener("click", function() {
		    this.gotoAndStop("halamansku");
		}.bind(this));
		this.stop();
	}
	this.frame_65 = function() {
		this.stop();
		
		this.btnhomekeke.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackkeke.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext7.addEventListener("click", function() {
		    this.gotoAndStop("halamanketmatianlanjutan");
		}.bind(this));
		this.stop();
	}
	this.frame_68 = function() {
		this.stop();
		
		this.btnTidak7.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa7.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop();
		
		this.btnhomekeke2.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackkeke2.addEventListener("click", function() {
		    this.gotoAndStop("halamanketmati");
		}.bind(this));
	}
	this.frame_70 = function() {
		this.stop();
		
		this.btnhomenikah1.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbacknikah1.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext8.addEventListener("click", function() {
		    this.gotoAndStop("halamannikahlanjutan");
		}.bind(this));
		this.stop()
		
		this.btnhomenikah1.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnhomenikah1.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
	}
	this.frame_73 = function() {
		this.stop();
		
		this.btnTidak8.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa8.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		
		this.btnhomenikah2.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbacknikah2.addEventListener("click", function() {
		    this.gotoAndStop("halamannikah");
		}.bind(this));
		this.stop();
	}
	this.frame_75 = function() {
		this.stop();
		
		this.btnhome9.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback9.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext9.addEventListener("click", function() {
		    this.gotoAndStop("halamanbelumnikahlanjutan");
		}.bind(this));
		this.stop();
	}
	this.frame_78 = function() {
		this.stop();
		
		this.btnTidak9.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa9.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop();
		
		this.btnhome9_1.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback9_1.addEventListener("click", function() {
		    this.gotoAndStop("halamanbelumnikah");
		}.bind(this));
	}
	this.frame_80 = function() {
		this.stop();
		
		this.btnsktm1.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnsktm1.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext10.addEventListener("click", function() {
		    this.gotoAndStop("halamansktmlanjutan");
		}.bind(this));
		this.stop();
	}
	this.frame_83 = function() {
		this.stop();
		
		this.btnTidak10.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa10.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		
		this.btnhome10.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback10.addEventListener("click", function() {
		    this.gotoAndStop("halamansktm");
		}.bind(this));
		this.stop();
	}
	this.frame_85 = function() {
		this.stop()
		
		this.btnnext11.addEventListener("click", function() {
		    this.gotoAndStop("halamansdtslanjutan");
		}.bind(this));
		this.stop();
		
		this.btnhome11.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback11.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
	}
	this.frame_88 = function() {
		this.stop();
		
		this.btnTidak11.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa11.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop()
		
		this.btnhomedom.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackdom.addEventListener("click", function() {
		    this.gotoAndStop("halamansdts");
		}.bind(this));
	}
	this.frame_90 = function() {
		this.stop();
		
		this.btnhome12.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback12.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext12.addEventListener("click", function() {
		    this.gotoAndStop("halamanbpjslanjutan");
		}.bind(this));
	}
	this.frame_93 = function() {
		this.stop()
		
		this.btnTidak12.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa12.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop()
		
		this.btnhomenpjs.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackbpjs.addEventListener("click", function() {
		    this.gotoAndStop("halamanbpjs");
		}.bind(this));
	}
	this.frame_95 = function() {
		this.stop();
		
		this.btnhomedaerah.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackdaerah.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext13.addEventListener("click", function() {
		    this.gotoAndStop("halamanpindahlanjutan");
		}.bind(this));
	}
	this.frame_98 = function() {
		this.stop()
		
		this.btnTidak13.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa13.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop()
		
		this.btnhome13.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback13.addEventListener("click", function() {
		    this.gotoAndStop("halamanpindah");
		}.bind(this));
	}
	this.frame_100 = function() {
		this.stop();
		
		this.btnhomedtks.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackdtks.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext14.addEventListener("click", function() {
		    this.gotoAndStop("halamandtkslanjutan");
		}.bind(this));
	}
	this.frame_103 = function() {
		this.stop()
		
		this.btnTidak14.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa14.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop()
		
		this.btnhome14.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback14.addEventListener("click", function() {
		    this.gotoAndStop("halamandtks");
		}.bind(this));
	}
	this.frame_105 = function() {
		this.stop();
		
		this.btnhomeskck.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackskck.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext15.addEventListener("click", function() {
		    this.gotoAndStop("halamanskcklanjutan");
		}.bind(this));
	}
	this.frame_108 = function() {
		this.stop()
		
		this.btnTidak15.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa15.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop()
		
		this.btnhome15.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback15.addEventListener("click", function() {
		    this.gotoAndStop("halamanskck");
		}.bind(this));
	}
	this.frame_110 = function() {
		this.stop();
		
		this.btnhomeberkas.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackberkas.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext16.addEventListener("click", function() {
		    this.gotoAndStop("halamanberkaslanjutan");
		}.bind(this));
	}
	this.frame_113 = function() {
		this.stop()
		
		this.btnTidak16.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa16.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
		this.stop()
		
		this.btnhome16.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback16.addEventListener("click", function() {
		    this.gotoAndStop("halamanberkas");
		}.bind(this));
	}
	this.frame_115 = function() {
		this.stop();
		
		this.btnhomebeda.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnbackbeda.addEventListener("click", function() {
		    this.gotoAndStop("halamanlayanan");
		}.bind(this));
		
		this.btnnext17.addEventListener("click", function() {
		    this.gotoAndStop("halamannamalanjutan");
		}.bind(this));
	}
	this.frame_118 = function() {
		this.stop()
		
		this.btnhome17.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnback17.addEventListener("click", function() {
		    this.gotoAndStop("halamannama");
		}.bind(this));
		
		this.btnTidak17.addEventListener("click", function() {
		    this.gotoAndStop("halamanutama");
		}.bind(this));
		
		this.btnYa17.addEventListener("click", function() {
		    this.gotoAndStop("halamandaftar");
		}.bind(this));
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4).call(this.frame_4).wait(5).call(this.frame_9).wait(2).call(this.frame_11).wait(8).call(this.frame_19).wait(3).call(this.frame_22).wait(5).call(this.frame_27).wait(5).call(this.frame_32).wait(5).call(this.frame_37).wait(3).call(this.frame_40).wait(3).call(this.frame_43).wait(2).call(this.frame_45).wait(3).call(this.frame_48).wait(2).call(this.frame_50).wait(3).call(this.frame_53).wait(2).call(this.frame_55).wait(3).call(this.frame_58).wait(2).call(this.frame_60).wait(3).call(this.frame_63).wait(2).call(this.frame_65).wait(3).call(this.frame_68).wait(2).call(this.frame_70).wait(3).call(this.frame_73).wait(2).call(this.frame_75).wait(3).call(this.frame_78).wait(2).call(this.frame_80).wait(3).call(this.frame_83).wait(2).call(this.frame_85).wait(3).call(this.frame_88).wait(2).call(this.frame_90).wait(3).call(this.frame_93).wait(2).call(this.frame_95).wait(3).call(this.frame_98).wait(2).call(this.frame_100).wait(3).call(this.frame_103).wait(2).call(this.frame_105).wait(3).call(this.frame_108).wait(2).call(this.frame_110).wait(3).call(this.frame_113).wait(2).call(this.frame_115).wait(3).call(this.frame_118).wait(2));

	// Layer_7
	this.instance = new lib.CachedBmp_2();
	this.instance.setTransform(1140.6,199.95,0.5,0.5);

	this.btnHomeR = new lib.btnHomeR();
	this.btnHomeR.name = "btnHomeR";
	this.btnHomeR.setTransform(113.6,174,1,1,0,0,0,44,44);

	this.btnBackR = new lib.btnBackR();
	this.btnBackR.name = "btnBackR";
	this.btnBackR.setTransform(235.6,174,1,1,0,0,0,44,44);

	this.instance_1 = new lib.CachedBmp_1();
	this.instance_1.setTransform(67.6,128,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1},{t:this.btnBackR},{t:this.btnHomeR},{t:this.instance}]},27).to({state:[]},3).to({state:[]},7).wait(83));

	// Layer_6
	this.backloket1 = new lib.backloket1();
	this.backloket1.name = "backloket1";
	this.backloket1.setTransform(224,169,1,1,0,0,0,44,44);

	this.homeloket1 = new lib.homeloket();
	this.homeloket1.name = "homeloket1";
	this.homeloket1.setTransform(115,169,1,1,0,0,0,44,44);

	this.btnriwayat = new lib.btnriwayat();
	this.btnriwayat.name = "btnriwayat";
	this.btnriwayat.setTransform(845.1,475.5,1,1,0,0,0,76.1,84.5);

	this.btnpendaftaran = new lib.btnpendaftaran();
	this.btnpendaftaran.name = "btnpendaftaran";
	this.btnpendaftaran.setTransform(501.1,475.5,1,1,0,0,0,76.1,84.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#66CC99").ss(4,1,1).p("ABpm3INwAAIAANvItwAAgAvYm3INwAAIAANvItwAAg");
	this.shape.setTransform(169.5,169);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(2,1,1).p("AAAm/IAAN/");
	this.shape_1.setTransform(168.75,169);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("EhhSghCMDClAAAMAAABCFMjClAAAgAL2sdIXyAAIAAabI3yAAgEgp5gMdIXyAAIAAabI3yAAg");
	this.shape_2.setTransform(693.225,470.8);

	this.instance_2 = new lib.CachedBmp_8();
	this.instance_2.setTransform(1160.95,550.25,0.5,0.5);

	this.btnSubmit = new lib.btnSubmit();
	this.btnSubmit.name = "btnSubmit";
	this.btnSubmit.setTransform(1207.45,560.95,1,1,0,0,0,58.8,22.9);

	this.instance_3 = new lib.CachedBmp_7();
	this.instance_3.setTransform(998.95,550.25,0.5,0.5);

	this.btnBatal = new lib.btnBatal();
	this.btnBatal.name = "btnBatal";
	this.btnBatal.setTransform(1043.45,560.75,1,1,0,0,0,63.3,23);

	this.txtTanggal = new cjs.Text("", "15px 'Verdana'");
	this.txtTanggal.name = "txtTanggal";
	this.txtTanggal.lineHeight = 20;
	this.txtTanggal.lineWidth = 205;
	this.txtTanggal.parent = this;
	this.txtTanggal.setTransform(891.4,411.65);

	this.instance_4 = new lib.CachedBmp_6();
	this.instance_4.setTransform(805.55,409.65,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_5();
	this.instance_5.setTransform(805.55,445,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_4();
	this.instance_6.setTransform(805.55,376.35,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_3();
	this.instance_7.setTransform(792.8,357.6,0.5,0.5);

	this.btnNext = new lib.btnNext();
	this.btnNext.name = "btnNext";
	this.btnNext.setTransform(807.15,692.25,1,1,0,0,0,35.5,21.2);

	this.btnPrev = new lib.btnPrev();
	this.btnPrev.name = "btnPrev";
	this.btnPrev.setTransform(549.45,692.25,1,1,0,0,0,35.5,21.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(2,1,1).p("AAAnGIAAON");
	this.shape_3.setTransform(173.8,175.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("EhimglTMDFNAAAMAAABAlMjFNAAAgANtesILGAAIAAGoIrGAAgASqfyIAAEOICniLgAn4ekIMpAAIAAGnIspAAgA0VfxIAAEZIi2iHgA6jesILGAAIAAGoIrGAAg");
	this.shape_4.setTransform(683.95,474.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00CCCC").s().p("A2NAGIC2iSIAAEZgAToiKICnCDIinCKg");
	this.shape_5.setTransform(677.8,691.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("EgH4AlQIAAmnIMqAAIAAGngEhilAbWMAAAhAlMDFLAAAMAAABAlg");
	this.shape_6.setTransform(683.95,474.175);

	this.txtLayanan = new cjs.Text("", "22px 'Arial Rounded MT Bold'");
	this.txtLayanan.name = "txtLayanan";
	this.txtLayanan.lineHeight = 27;
	this.txtLayanan.lineWidth = 330;
	this.txtLayanan.parent = this;
	this.txtLayanan.setTransform(371.45,508.6);

	this.txtEmail = new cjs.Text("", "20px 'Arial Rounded MT Bold'");
	this.txtEmail.name = "txtEmail";
	this.txtEmail.lineHeight = 25;
	this.txtEmail.lineWidth = 195;
	this.txtEmail.parent = this;
	this.txtEmail.setTransform(558.4,409.4);

	this.txtNama = new cjs.Text("", "20px 'Arial Rounded MT Bold'");
	this.txtNama.name = "txtNama";
	this.txtNama.lineHeight = 25;
	this.txtNama.lineWidth = 192;
	this.txtNama.parent = this;
	this.txtNama.setTransform(558.4,354.1);

	this.txtNoAntrian = new cjs.Text("", "80px 'Arial Rounded MT Bold'");
	this.txtNoAntrian.name = "txtNoAntrian";
	this.txtNoAntrian.textAlign = "center";
	this.txtNoAntrian.lineHeight = 95;
	this.txtNoAntrian.lineWidth = 91;
	this.txtNoAntrian.parent = this;
	this.txtNoAntrian.setTransform(879.7,354.1);

	this.txtNoLoket = new cjs.Text("", "30px 'Arial Rounded MT Bold'");
	this.txtNoLoket.name = "txtNoLoket";
	this.txtNoLoket.textAlign = "center";
	this.txtNoLoket.lineHeight = 37;
	this.txtNoLoket.lineWidth = 36;
	this.txtNoLoket.parent = this;
	this.txtNoLoket.setTransform(715.5,238.1);

	this.btnBack = new lib.btnBack_1();
	this.btnBack.name = "btnBack";
	this.btnBack.setTransform(72.5,163.45,1,1,0,0,0,34.2,35.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#66CC99").ss(4,1,1).p("AlWliIKtAAIAALEIqtAAg");
	this.shape_7.setTransform(72.575,163.4);

	this.backInfo = new lib.backInfo();
	this.backInfo.name = "backInfo";
	this.backInfo.setTransform(180.9,162.05,0.1876,0.1807,0,0,0,234.8,243.5);

	this.homeInfo = new lib.homeInfo();
	this.homeInfo.name = "homeInfo";
	this.homeInfo.setTransform(68.4,163,0.1913,0.1868,0,0,0,230,235.2);

	this.instance_8 = new lib.CachedBmp_12();
	this.instance_8.setTransform(1097,337.35,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_11();
	this.instance_9.setTransform(671.45,337.35,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_10();
	this.instance_10.setTransform(260.65,337.35,0.5,0.5);

	this.btnTlp = new lib.btnTlp();
	this.btnTlp.name = "btnTlp";
	this.btnTlp.setTransform(279.1,348,1,1,0,0,0,130.2,19.5);

	this.btnWeb = new lib.btnWeb();
	this.btnWeb.name = "btnWeb";
	this.btnWeb.setTransform(1115.5,348.15,1,1,0,0,0,130.3,19.3);

	this.btnEmail = new lib.btnEmail();
	this.btnEmail.name = "btnEmail";
	this.btnEmail.setTransform(689.95,348.5,1,1,0,0,0,130.5,19.5);

	this.instance_11 = new lib.CachedBmp_9();
	this.instance_11.setTransform(22,117,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.btnpendaftaran},{t:this.btnriwayat},{t:this.homeloket1},{t:this.backloket1}]},19).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.txtTanggal,p:{x:891.4,y:411.65,font:"15px 'Verdana'",textAlign:"",lineHeight:20.25,lineWidth:205,color:"#000000"}},{t:this.btnBatal},{t:this.instance_3},{t:this.btnSubmit},{t:this.instance_2}]},3).to({state:[]},3).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.txtTanggal,p:{x:672.9,y:673.05,font:"15px 'ArialRoundedMTBold'",textAlign:"center",lineHeight:19.35,lineWidth:48,color:"#000000"}},{t:this.btnPrev},{t:this.btnNext}]},2).to({state:[]},3).to({state:[{t:this.shape_7},{t:this.btnBack},{t:this.txtNoLoket},{t:this.txtNoAntrian},{t:this.txtNama},{t:this.txtEmail},{t:this.txtLayanan},{t:this.txtTanggal,p:{x:689,y:631.5,font:"17px 'Arial Rounded MT Bold'",textAlign:"center",lineHeight:21.7,lineWidth:144,color:"#FFFFFF"}}]},2).to({state:[]},3).to({state:[{t:this.instance_11},{t:this.btnEmail},{t:this.btnWeb},{t:this.btnTlp},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.homeInfo},{t:this.backInfo}]},2).to({state:[]},3).wait(80));

	// Layer_5
	this.instance_12 = new lib.CachedBmp_14();
	this.instance_12.setTransform(96.4,225.1,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_13();
	this.instance_13.setTransform(70.05,220.25,0.5,0.5);

	this.back3 = new lib.back3_1();
	this.back3.name = "back3";
	this.back3.setTransform(208.9,179.5,0.1876,0.1807,0,0,0,234.5,243.5);

	this.home3 = new lib.home3_1();
	this.home3.name = "home3";
	this.home3.setTransform(78.55,179.55,0.1913,0.1868,0,0,0,230,235.8);

	this.instance_14 = new lib.CachedBmp_18();
	this.instance_14.setTransform(91.75,519.15,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_17();
	this.instance_15.setTransform(91.75,413.9,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_16();
	this.instance_16.setTransform(91.75,312.6,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_15();
	this.instance_17.setTransform(32.55,133.5,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("AACAAIgDAA");
	this.shape_8.setTransform(59.475,173.8);

	this.instance_18 = new lib.CachedBmp_27();
	this.instance_18.setTransform(497.3,659.05,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_26();
	this.instance_19.setTransform(536.45,633.25,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_25();
	this.instance_20.setTransform(514,600.2,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_24();
	this.instance_21.setTransform(369.05,465.45,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_23();
	this.instance_22.setTransform(369.05,407.4,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_22();
	this.instance_23.setTransform(369.45,352.1,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_21();
	this.instance_24.setTransform(789.5,304.15,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_20();
	this.instance_25.setTransform(551.05,235.55,0.5,0.5);

	this.instance_26 = new lib.CachedBmp_19();
	this.instance_26.setTransform(340.4,202.45,0.5,0.5);

	this.instance_27 = new lib.CachedBmp_32();
	this.instance_27.setTransform(985.95,287.75,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_31();
	this.instance_28.setTransform(559.45,287.75,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_30();
	this.instance_29.setTransform(148.45,292.1,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_29();
	this.instance_30.setTransform(52.75,220.5,0.5,0.5);

	this.instance_31 = new lib.CachedBmp_28();
	this.instance_31.setTransform(23.5,224.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_13},{t:this.instance_12}]},19).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.home3},{t:this.back3}]},3).to({state:[]},3).to({state:[{t:this.shape_8}]},2).to({state:[]},3).to({state:[{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18}]},2).to({state:[]},3).to({state:[{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27}]},2).to({state:[]},3).wait(80));

	// Layer_4
	this.whatsA = new lib.whatsA();
	this.whatsA.name = "whatsA";
	this.whatsA.setTransform(1242.4,54.6,1,1,0,0,0,31.4,33.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#66CC99").ss(4,1,1).p("EAlQgMgIXyAAIAAZBI3yAAgAsQsgIXxAAIAAZBI3xAAgEg9BgMgIXyAAIAAZBI3yAAg");
	this.shape_9.setTransform(667.525,404.05);

	this.logokota1 = new lib.logokota1();
	this.logokota1.name = "logokota1";
	this.logokota1.setTransform(87.1,55.15,0.1358,0.1296,0,0,180,638.6,425.4);

	this.instance_32 = new lib.CachedBmp_35();
	this.instance_32.setTransform(196.55,63.2,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_34();
	this.instance_33.setTransform(191.6,0,0.5,0.5);

	this.instance_34 = new lib.BGweb();
	this.instance_34.setTransform(0,110,1.0703,0.7327);

	this.instance_35 = new lib.CachedBmp_850();
	this.instance_35.setTransform(0.2,0,0.5,0.5);

	this.instance_36 = new lib.CachedBmp_38();
	this.instance_36.setTransform(196.55,63.2,0.5,0.5);

	this.instance_37 = new lib.CachedBmp_37();
	this.instance_37.setTransform(191.6,0,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_36();
	this.instance_38.setTransform(-4,0,0.5,0.5);

	this.instance_39 = new lib.CachedBmp_41();
	this.instance_39.setTransform(196.55,63.2,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_40();
	this.instance_40.setTransform(191.6,0,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_44();
	this.instance_41.setTransform(196.55,63.2,0.5,0.5);

	this.instance_42 = new lib.CachedBmp_43();
	this.instance_42.setTransform(191.6,0,0.5,0.5);

	this.instance_43 = new lib.CachedBmp_42();
	this.instance_43.setTransform(0.2,0,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_47();
	this.instance_44.setTransform(196.55,63.2,0.5,0.5);

	this.instance_45 = new lib.CachedBmp_46();
	this.instance_45.setTransform(191.6,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.whatsA}]}).to({state:[]},4).to({state:[{t:this.instance_35},{t:this.instance_34,p:{x:0,y:110}},{t:this.instance_33},{t:this.instance_32},{t:this.logokota1}]},15).to({state:[{t:this.instance_38},{t:this.instance_34,p:{x:-4,y:107}},{t:this.instance_37},{t:this.instance_36},{t:this.logokota1}]},3).to({state:[]},3).to({state:[{t:this.instance_35},{t:this.instance_34,p:{x:0,y:110}},{t:this.instance_40},{t:this.instance_39},{t:this.logokota1}]},2).to({state:[]},3).to({state:[{t:this.instance_43},{t:this.instance_34,p:{x:0,y:110}},{t:this.instance_42},{t:this.instance_41},{t:this.logokota1}]},2).to({state:[]},3).to({state:[{t:this.instance_35},{t:this.instance_34,p:{x:0,y:110}},{t:this.instance_45},{t:this.instance_44},{t:this.logokota1}]},2).to({state:[]},3).wait(80));

	// Layer_3
	this.instag = new lib.Insta();
	this.instag.name = "instag";
	this.instag.setTransform(1037.35,54.55,1,1,0,0,0,31.4,33.6);

	this.instance_46 = new lib.CachedBmp_49();
	this.instance_46.setTransform(46.55,254.25,0.5,0.5);

	this.instance_47 = new lib.CachedBmp_48();
	this.instance_47.setTransform(52.2,253,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instag}]}).to({state:[]},4).to({state:[{t:this.instance_47},{t:this.instance_46}]},5).to({state:[]},2).to({state:[]},3).wait(106));

	// Layer_2
	this.faceb = new lib.Fb();
	this.faceb.name = "faceb";
	this.faceb.setTransform(1137.05,54.5,1,1,0,0,0,31.4,33.6);

	this.instance_48 = new lib.CachedBmp_898();
	this.instance_48.setTransform(1007.5,378.65,0.5,0.5);

	this.btnbeda = new lib.btnbeda();
	this.btnbeda.name = "btnbeda";
	this.btnbeda.setTransform(1180,403.3,1,1,0,0,0,150.3,28.5);

	this.instance_49 = new lib.CachedBmp_897();
	this.instance_49.setTransform(1011.2,310.45,0.5,0.5);

	this.btnskck = new lib.btnskck();
	this.btnskck.name = "btnskck";
	this.btnskck.setTransform(1180,329.1,1,1,0,0,0,150.3,28.5);

	this.instance_50 = new lib.CachedBmp_896();
	this.instance_50.setTransform(681.7,626.1,0.5,0.5);

	this.btnberkas = new lib.btnberkas();
	this.btnberkas.name = "btnberkas";
	this.btnberkas.setTransform(857.2,638.9,1,1,0,0,0,150.3,28.5);

	this.instance_51 = new lib.CachedBmp_911();
	this.instance_51.setTransform(706.9,533.75,0.5,0.5);

	this.btndtks = new lib.btndtks();
	this.btndtks.name = "btndtks";
	this.btndtks.setTransform(857.2,557.3,1,1,0,0,0,150.3,28.5);

	this.instance_52 = new lib.CachedBmp_910();
	this.instance_52.setTransform(678.65,392.15,0.5,0.5);

	this.btnbpjs = new lib.btnbpjs();
	this.btnbpjs.name = "btnbpjs";
	this.btnbpjs.setTransform(857.2,403.3,1,1,0,0,0,150.3,28.5);

	this.instance_53 = new lib.CachedBmp_909();
	this.instance_53.setTransform(681.7,316.15,0.5,0.5);

	this.btndomisili = new lib.btndomisili();
	this.btndomisili.name = "btndomisili";
	this.btndomisili.setTransform(857.2,329.1,1,1,0,0,0,150.3,28.5);

	this.instance_54 = new lib.CachedBmp_908();
	this.instance_54.setTransform(344.8,630.25,0.5,0.5);

	this.btnsktm = new lib.btnsktm();
	this.btnsktm.name = "btnsktm";
	this.btnsktm.setTransform(515.95,638.9,1,1,0,0,0,150.3,28.5);

	this.instance_55 = new lib.CachedBmp_907();
	this.instance_55.setTransform(340.45,544.65,0.5,0.5);

	this.btnbelumnikah = new lib.btnbelumnikah();
	this.btnbelumnikah.name = "btnbelumnikah";
	this.btnbelumnikah.setTransform(515.95,557.3,1,1,0,0,0,150.3,28.5);

	this.instance_56 = new lib.CachedBmp_906();
	this.instance_56.setTransform(340.45,468.45,0.5,0.5);

	this.btnnikah = new lib.btnnikah();
	this.btnnikah.name = "btnnikah";
	this.btnnikah.setTransform(515.95,482.3,1,1,0,0,0,150.3,28.5);

	this.instance_57 = new lib.CachedBmp_905();
	this.instance_57.setTransform(340.45,392.15,0.5,0.5);

	this.btnskm = new lib.btnskm();
	this.btnskm.name = "btnskm";
	this.btnskm.setTransform(515.95,403.3,1,1,0,0,0,150.3,28.5);

	this.instance_58 = new lib.CachedBmp_904();
	this.instance_58.setTransform(330.65,316.15,0.5,0.5);

	this.btnsku = new lib.btnsku();
	this.btnsku.name = "btnsku";
	this.btnsku.setTransform(515.95,329.1,1,1,0,0,0,150.3,28.5);

	this.instance_59 = new lib.CachedBmp_903();
	this.instance_59.setTransform(22.45,630.25,0.5,0.5);

	this.btnkia = new lib.btnkia();
	this.btnkia.name = "btnkia";
	this.btnkia.setTransform(194.5,638.9,1,1,0,0,0,150.3,28.5);

	this.instance_60 = new lib.CachedBmp_902();
	this.instance_60.setTransform(22.45,544.65,0.5,0.5);

	this.btnktp = new lib.btnktp();
	this.btnktp.name = "btnktp";
	this.btnktp.setTransform(194.5,557.3,1,1,0,0,0,150.3,28.5);

	this.instance_61 = new lib.CachedBmp_901();
	this.instance_61.setTransform(22.45,468.45,0.5,0.5);

	this.btnkematian = new lib.btnkematian();
	this.btnkematian.name = "btnkematian";
	this.btnkematian.setTransform(194.5,482.3,1,1,0,0,0,150.3,28.5);

	this.instance_62 = new lib.CachedBmp_900();
	this.instance_62.setTransform(22.45,392.15,0.5,0.5);

	this.btnkelahiran = new lib.btnkelahiran();
	this.btnkelahiran.name = "btnkelahiran";
	this.btnkelahiran.setTransform(194.5,403.3,1,1,0,0,0,150.3,28.5);

	this.instance_63 = new lib.CachedBmp_899();
	this.instance_63.setTransform(22.45,316.15,0.5,0.5);

	this.btnkk = new lib.btnkk();
	this.btnkk.name = "btnkk";
	this.btnkk.setTransform(194.5,329.1,1,1,0,0,0,150.3,28.5);

	this.text = new cjs.Text("Layanan Publik", "30px 'Arial Rounded MT Bold'", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 37;
	this.text.lineWidth = 247;
	this.text.parent = this;
	this.text.setTransform(1224.8,211.6);

	this.instance_64 = new lib.CachedBmp_895();
	this.instance_64.setTransform(681.7,468.45,0.5,0.5);

	this.btnpindahkk = new lib.btnpindahkk();
	this.btnpindahkk.name = "btnpindahkk";
	this.btnpindahkk.setTransform(857.2,482.3,1,1,0,0,0,150.3,28.5);

	this.btnkk_1 = new lib.tombolkk();
	this.btnkk_1.name = "btnkk_1";
	this.btnkk_1.setTransform(194.5,329.1,1,1,0,0,0,150.3,28.5);

	this.btnkembali = new lib.tombolkembali();
	this.btnkembali.name = "btnkembali";
	this.btnkembali.setTransform(174.95,188.75,2.5215,2.5,0,0,0,17.4,17.6);

	this.btnhome = new lib.tombolhome();
	this.btnhome.name = "btnhome";
	this.btnhome.setTransform(66.4,189.05,1.772,1.8001,0,0,0,24.8,24.6);

	this.instance_65 = new lib.CachedBmp_50();
	this.instance_65.setTransform(20.45,142.75,0.5,0.5);

	this.btnnext1 = new lib.btnnext1();
	this.btnnext1.name = "btnnext1";
	this.btnnext1.setTransform(1208.05,668.45,1,1,0,0,0,80.5,23.2);

	this.instance_66 = new lib.CachedBmp_476();
	this.instance_66.setTransform(98.4,420.85,0.5,0.5);

	this.instance_67 = new lib.CachedBmp_475();
	this.instance_67.setTransform(52.7,318.95,0.5,0.5);

	this.instance_68 = new lib.CachedBmp_474();
	this.instance_68.setTransform(31.8,135.9,0.5,0.5);

	this.btnYa1 = new lib.btnYa1();
	this.btnYa1.name = "btnYa1";
	this.btnYa1.setTransform(739.3,669.85,1,1,0,0,0,75.2,17.2);

	this.text_1 = new cjs.Text("Tidak", "20px 'Tw Cen MT Condensed Extra Bold'", "#FFFFFF");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 24;
	this.text_1.lineWidth = 122;
	this.text_1.parent = this;
	this.text_1.setTransform(551.3,660.2);

	this.btnTidak1 = new lib.btnTidak1();
	this.btnTidak1.name = "btnTidak1";
	this.btnTidak1.setTransform(551.35,671.45,1,1,0,0,0,79.4,18.8);

	this.text_2 = new cjs.Text("Ingin lanjut ke\nPendaftaran Loket?", "20px 'Tw Cen MT Condensed Extra Bold'");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 24;
	this.text_2.lineWidth = 507;
	this.text_2.parent = this;
	this.text_2.setTransform(664.65,584.35);

	this.instance_69 = new lib.CachedBmp_487();
	this.instance_69.setTransform(681,283.1,0.5,0.5);

	this.instance_70 = new lib.CachedBmp_486();
	this.instance_70.setTransform(641.15,247.2,0.5,0.5);

	this.instance_71 = new lib.CachedBmp_485();
	this.instance_71.setTransform(369.6,483.1,0.5,0.5);

	this.instance_72 = new lib.CachedBmp_484();
	this.instance_72.setTransform(223.05,483.1,0.5,0.5);

	this.instance_73 = new lib.CachedBmp_483();
	this.instance_73.setTransform(44.15,483.1,0.5,0.5);

	this.instance_74 = new lib.BukuNikah();
	this.instance_74.setTransform(394,352,0.226,0.2354);

	this.instance_75 = new lib.CachedBmp_482();
	this.instance_75.setTransform(369.6,348.55,0.5,0.5);

	this.instance_76 = new lib.CachedBmp_481();
	this.instance_76.setTransform(210.6,348.55,0.5,0.5);

	this.instance_77 = new lib.CachedBmp_480();
	this.instance_77.setTransform(52.7,349,0.5,0.5);

	this.instance_78 = new lib.KTP();
	this.instance_78.setTransform(232,352,0.2472,0.2366);

	this.instance_79 = new lib.KartuKeluarga();
	this.instance_79.setTransform(74,349,0.2061,0.241);

	this.instance_80 = new lib.CachedBmp_479();
	this.instance_80.setTransform(28.5,304.05,0.5,0.5);

	this.instance_81 = new lib.CachedBmp_478();
	this.instance_81.setTransform(59.1,242.85,0.5,0.5);

	this.instance_82 = new lib.CachedBmp_477();
	this.instance_82.setTransform(28,118.9,0.5,0.5);

	this.btnback3 = new lib.btnback3();
	this.btnback3.name = "btnback3";
	this.btnback3.setTransform(200.9,173.6,1,1,0,0,0,44,44);

	this.btnnext2 = new lib.btnnext2();
	this.btnnext2.name = "btnnext2";
	this.btnnext2.setTransform(1229.2,668.6,1,1,0,0,0,80.5,23.2);

	this.btnhome3 = new lib.btnhome3();
	this.btnhome3.name = "btnhome3";
	this.btnhome3.setTransform(76.1,174,1,1,0,0,0,44,44);

	this.instance_83 = new lib.CachedBmp_491();
	this.instance_83.setTransform(71.45,407.4,0.5,0.5);

	this.instance_84 = new lib.CachedBmp_490();
	this.instance_84.setTransform(52.7,295.7,0.5,0.5);

	this.instance_85 = new lib.CachedBmp_489();
	this.instance_85.setTransform(71.45,258.6,0.5,0.5);

	this.instance_86 = new lib.CachedBmp_745();
	this.instance_86.setTransform(31.6,128,0.5,0.5);

	this.btnYa2 = new lib.btnYa2();
	this.btnYa2.name = "btnYa2";
	this.btnYa2.setTransform(703.95,660.2,1,1,0,0,0,57.6,18);

	this.btnTidak2 = new lib.btnTidak2();
	this.btnTidak2.name = "btnTidak2";
	this.btnTidak2.setTransform(573.05,660.2,1,1,0,0,0,57.6,18);

	this.instance_87 = new lib.CachedBmp_503();
	this.instance_87.setTransform(434.1,586.95,0.5,0.5);

	this.instance_88 = new lib.CachedBmp_502();
	this.instance_88.setTransform(680.9,310.75,0.5,0.5);

	this.instance_89 = new lib.CachedBmp_501();
	this.instance_89.setTransform(642.4,245.8,0.5,0.5);

	this.instance_90 = new lib.CachedBmp_500();
	this.instance_90.setTransform(213.25,481.7,0.5,0.5);

	this.instance_91 = new lib.CachedBmp_499();
	this.instance_91.setTransform(392.25,481.7,0.5,0.5);

	this.instance_92 = new lib.CachedBmp_498();
	this.instance_92.setTransform(45.4,481.7,0.5,0.5);

	this.instance_93 = new lib.CachedBmp_497();
	this.instance_93.setTransform(370.85,347.15,0.5,0.5);

	this.instance_94 = new lib.CachedBmp_496();
	this.instance_94.setTransform(211.85,347.15,0.5,0.5);

	this.instance_95 = new lib.CachedBmp_495();
	this.instance_95.setTransform(53.95,347.6,0.5,0.5);

	this.instance_96 = new lib.CachedBmp_494();
	this.instance_96.setTransform(29.75,302.65,0.5,0.5);

	this.instance_97 = new lib.CachedBmp_493();
	this.instance_97.setTransform(59.1,251.45,0.5,0.5);

	this.instance_98 = new lib.CachedBmp_749();
	this.instance_98.setTransform(29.25,117.5,0.5,0.5);

	this.btnnext3 = new lib.btnnext3();
	this.btnnext3.name = "btnnext3";
	this.btnnext3.setTransform(1225,671.55,1,1,0,0,0,80.5,23.2);

	this.btnbackktp1 = new lib.btnbackktp1();
	this.btnbackktp1.name = "btnbackktp1";
	this.btnbackktp1.setTransform(186,174,1,1,0,0,0,44,44);

	this.btnhomektp1 = new lib.btnhomektp1();
	this.btnhomektp1.name = "btnhomektp1";
	this.btnhomektp1.setTransform(77,174,1,1,0,0,0,44,44);

	this.instance_99 = new lib.CachedBmp_507();
	this.instance_99.setTransform(67.25,410.35,0.5,0.5);

	this.instance_100 = new lib.CachedBmp_506();
	this.instance_100.setTransform(48.5,298.65,0.5,0.5);

	this.instance_101 = new lib.CachedBmp_505();
	this.instance_101.setTransform(67.25,261.55,0.5,0.5);

	this.instance_102 = new lib.CachedBmp_504();
	this.instance_102.setTransform(27.4,128,0.5,0.5);

	this.btnYa3 = new lib.btnYa3();
	this.btnYa3.name = "btnYa3";
	this.btnYa3.setTransform(703.95,667.55,1,1,0,0,0,57.6,18);

	this.btnTidak3 = new lib.btnTidak3();
	this.btnTidak3.name = "btnTidak3";
	this.btnTidak3.setTransform(573.05,667.55,1,1,0,0,0,57.6,18);

	this.instance_103 = new lib.logoberbentuksurat();
	this.instance_103.setTransform(243,355,0.1079,0.128);

	this.instance_104 = new lib.CachedBmp_517();
	this.instance_104.setTransform(434.1,594.3,0.5,0.5);

	this.instance_105 = new lib.CachedBmp_516();
	this.instance_105.setTransform(680.9,327.8,0.5,0.5);

	this.instance_106 = new lib.CachedBmp_515();
	this.instance_106.setTransform(642.4,253.15,0.5,0.5);

	this.instance_107 = new lib.CachedBmp_514();
	this.instance_107.setTransform(237.05,490.3,0.5,0.5);

	this.instance_108 = new lib.CachedBmp_513();
	this.instance_108.setTransform(48.6,490.3,0.5,0.5);

	this.instance_109 = new lib.CachedBmp_512();
	this.instance_109.setTransform(211.85,354.5,0.5,0.5);

	this.instance_110 = new lib.CachedBmp_511();
	this.instance_110.setTransform(53.95,354.95,0.5,0.5);

	this.instance_111 = new lib.CachedBmp_510();
	this.instance_111.setTransform(29.75,310,0.5,0.5);

	this.instance_112 = new lib.CachedBmp_509();
	this.instance_112.setTransform(60.35,248.8,0.5,0.5);

	this.btnbackkia1 = new lib.btnbackkia1();
	this.btnbackkia1.name = "btnbackkia1";
	this.btnbackkia1.setTransform(194,180,1,1,0,0,0,44,44);

	this.btnhomekia1 = new lib.btnhomekia1();
	this.btnhomekia1.name = "btnhomekia1";
	this.btnhomekia1.setTransform(77,180,1,1,0,0,0,44,44);

	this.btnnext4 = new lib.btnnext4();
	this.btnnext4.name = "btnnext4";
	this.btnnext4.setTransform(1230.55,679.35,1,1,0,0,0,80.5,23.2);

	this.instance_113 = new lib.CachedBmp_521();
	this.instance_113.setTransform(72.8,418.15,0.5,0.5);

	this.instance_114 = new lib.CachedBmp_520();
	this.instance_114.setTransform(54.05,306.45,0.5,0.5);

	this.instance_115 = new lib.CachedBmp_519();
	this.instance_115.setTransform(72.8,252.75,0.5,0.5);

	this.instance_116 = new lib.CachedBmp_518();
	this.instance_116.setTransform(32.95,134.4,0.5,0.5);

	this.btnYa4 = new lib.btnYa4();
	this.btnYa4.name = "btnYa4";
	this.btnYa4.setTransform(710.4,666.3,1,1,0,0,0,57.6,18);

	this.btnTidak4 = new lib.btnTidak4();
	this.btnTidak4.name = "btnTidak4";
	this.btnTidak4.setTransform(579.5,666.3,1,1,0,0,0,57.6,18);

	this.instance_117 = new lib.Desainlogountukcetakfoto();
	this.instance_117.setTransform(422,354,0.1079,0.128);

	this.instance_118 = new lib.DesainlogountukAk();
	this.instance_118.setTransform(246,354,0.1079,0.128);

	this.instance_119 = new lib.CachedBmp_533();
	this.instance_119.setTransform(440.55,593.05,0.5,0.5);

	this.instance_120 = new lib.CachedBmp_532();
	this.instance_120.setTransform(687.35,316.85,0.5,0.5);

	this.instance_121 = new lib.CachedBmp_531();
	this.instance_121.setTransform(648.85,251.9,0.5,0.5);

	this.instance_122 = new lib.CachedBmp_530();
	this.instance_122.setTransform(219.7,487.8,0.5,0.5);

	this.instance_123 = new lib.CachedBmp_529();
	this.instance_123.setTransform(409.7,490.2,0.5,0.5);

	this.instance_124 = new lib.CachedBmp_528();
	this.instance_124.setTransform(51.85,487.8,0.5,0.5);

	this.instance_125 = new lib.CachedBmp_527();
	this.instance_125.setTransform(377.3,353.25,0.5,0.5);

	this.instance_126 = new lib.CachedBmp_526();
	this.instance_126.setTransform(218.3,353.25,0.5,0.5);

	this.instance_127 = new lib.CachedBmp_525();
	this.instance_127.setTransform(60.4,353.7,0.5,0.5);

	this.instance_128 = new lib.CachedBmp_524();
	this.instance_128.setTransform(36.2,308.75,0.5,0.5);

	this.instance_129 = new lib.CachedBmp_523();
	this.instance_129.setTransform(71.5,244.7,0.5,0.5);

	this.btnbackmati1 = new lib.btnbackmati1();
	this.btnbackmati1.name = "btnbackmati1";
	this.btnbackmati1.setTransform(194,176,1,1,0,0,0,44,44);

	this.btnhomemati1 = new lib.btnhomemati1();
	this.btnhomemati1.name = "btnhomemati1";
	this.btnhomemati1.setTransform(78,176,1,1,0,0,0,44,44);

	this.btnnext5 = new lib.btnnext5();
	this.btnnext5.name = "btnnext5";
	this.btnnext5.setTransform(1230.6,670.3,1,1,0,0,0,80.5,23.2);

	this.instance_130 = new lib.CachedBmp_537();
	this.instance_130.setTransform(72.85,409.1,0.5,0.5);

	this.instance_131 = new lib.CachedBmp_536();
	this.instance_131.setTransform(54.1,312.25,0.5,0.5);

	this.instance_132 = new lib.CachedBmp_535();
	this.instance_132.setTransform(72.85,260.3,0.5,0.5);

	this.btnYa5 = new lib.btnYa5();
	this.btnYa5.name = "btnYa5";
	this.btnYa5.setTransform(702.75,668.2,1,1,0,0,0,57.6,18);

	this.btnTidak5 = new lib.btnTidak5();
	this.btnTidak5.name = "btnTidak5";
	this.btnTidak5.setTransform(571.85,668.2,1,1,0,0,0,57.6,18);

	this.instance_133 = new lib.CachedBmp_551();
	this.instance_133.setTransform(503.05,493.1,0.5,0.5);

	this.instance_134 = new lib.CachedBmp_550();
	this.instance_134.setTransform(503.05,355.15,0.5,0.5);

	this.instance_135 = new lib.CachedBmp_549();
	this.instance_135.setTransform(432.9,594.95,0.5,0.5);

	this.instance_136 = new lib.CachedBmp_548();
	this.instance_136.setTransform(679.7,318.75,0.5,0.5);

	this.instance_137 = new lib.CachedBmp_547();
	this.instance_137.setTransform(641.2,253.8,0.5,0.5);

	this.instance_138 = new lib.CachedBmp_546();
	this.instance_138.setTransform(196.95,493.1,0.5,0.5);

	this.instance_139 = new lib.CachedBmp_545();
	this.instance_139.setTransform(350,493.1,0.5,0.5);

	this.instance_140 = new lib.CachedBmp_544();
	this.instance_140.setTransform(44.2,489.7,0.5,0.5);

	this.instance_141 = new lib.CachedBmp_543();
	this.instance_141.setTransform(342.95,355.15,0.5,0.5);

	this.instance_142 = new lib.CachedBmp_542();
	this.instance_142.setTransform(196.95,355.15,0.5,0.5);

	this.instance_143 = new lib.CachedBmp_541();
	this.instance_143.setTransform(52.75,355.6,0.5,0.5);

	this.instance_144 = new lib.CachedBmp_540();
	this.instance_144.setTransform(28.55,310.65,0.5,0.5);

	this.instance_145 = new lib.CachedBmp_539();
	this.instance_145.setTransform(54.6,259.45,0.5,0.5);

	this.btnback6 = new lib.btnback6();
	this.btnback6.name = "btnback6";
	this.btnback6.setTransform(190,174,1,1,0,0,0,44,44);

	this.btnnext6 = new lib.btnnext6();
	this.btnnext6.name = "btnnext6";
	this.btnnext6.setTransform(1225.6,668.75,1,1,0,0,0,80.5,23.2);

	this.btnhome6 = new lib.btnhome6();
	this.btnhome6.name = "btnhome6";
	this.btnhome6.setTransform(72.5,174.15,1,1,0,0,0,44,44);

	this.instance_146 = new lib.CachedBmp_555();
	this.instance_146.setTransform(67.85,407.55,0.5,0.5);

	this.instance_147 = new lib.CachedBmp_554();
	this.instance_147.setTransform(49.1,295.85,0.5,0.5);

	this.instance_148 = new lib.CachedBmp_553();
	this.instance_148.setTransform(67.85,242.15,0.5,0.5);

	this.btnbacksku2 = new lib.btnbacksku2();
	this.btnbacksku2.name = "btnbacksku2";
	this.btnbacksku2.setTransform(194,162,1,1,0,0,0,44,44);

	this.btnhomesku2 = new lib.btnhomesku2();
	this.btnhomesku2.name = "btnhomesku2";
	this.btnhomesku2.setTransform(78,162,1,1,0,0,0,44,44);

	this.btnYa6 = new lib.btnYa6();
	this.btnYa6.name = "btnYa6";
	this.btnYa6.setTransform(703.75,658.9,1,1,0,0,0,57.6,18);

	this.btnTidak6 = new lib.btnTidak6();
	this.btnTidak6.name = "btnTidak6";
	this.btnTidak6.setTransform(572.85,658.9,1,1,0,0,0,57.6,18);

	this.instance_149 = new lib.Fotousaha();
	this.instance_149.setTransform(520,349,0.1079,0.128);

	this.instance_150 = new lib.suratrtrw();
	this.instance_150.setTransform(369,349,0.1079,0.128);

	this.instance_151 = new lib.CachedBmp_569();
	this.instance_151.setTransform(503.8,480.4,0.5,0.5);

	this.instance_152 = new lib.CachedBmp_568();
	this.instance_152.setTransform(492.4,345.85,0.5,0.5);

	this.instance_153 = new lib.CachedBmp_567();
	this.instance_153.setTransform(433.9,585.65,0.5,0.5);

	this.instance_154 = new lib.CachedBmp_566();
	this.instance_154.setTransform(680.7,309.45,0.5,0.5);

	this.instance_155 = new lib.CachedBmp_565();
	this.instance_155.setTransform(642.2,244.5,0.5,0.5);

	this.instance_156 = new lib.CachedBmp_564();
	this.instance_156.setTransform(196.35,480.4,0.5,0.5);

	this.instance_157 = new lib.CachedBmp_563();
	this.instance_157.setTransform(361.55,480.4,0.5,0.5);

	this.instance_158 = new lib.CachedBmp_562();
	this.instance_158.setTransform(45.2,480.4,0.5,0.5);

	this.instance_159 = new lib.CachedBmp_561();
	this.instance_159.setTransform(343.95,345.85,0.5,0.5);

	this.instance_160 = new lib.CachedBmp_560();
	this.instance_160.setTransform(196.35,345.85,0.5,0.5);

	this.instance_161 = new lib.CachedBmp_559();
	this.instance_161.setTransform(53.75,346.3,0.5,0.5);

	this.instance_162 = new lib.CachedBmp_558();
	this.instance_162.setTransform(29.55,301.35,0.5,0.5);

	this.instance_163 = new lib.CachedBmp_557();
	this.instance_163.setTransform(60.15,240.15,0.5,0.5);

	this.instance_164 = new lib.CachedBmp_677();
	this.instance_164.setTransform(29.05,116.2,0.5,0.5);

	this.btnnext7 = new lib.btnnext7();
	this.btnnext7.name = "btnnext7";
	this.btnnext7.setTransform(1232.45,658.65,1,1,0,0,0,80.5,23.2);

	this.instance_165 = new lib.CachedBmp_574();
	this.instance_165.setTransform(1464.15,476.4,0.5,0.5);

	this.instance_166 = new lib.CachedBmp_573();
	this.instance_166.setTransform(74.7,397.45,0.5,0.5);

	this.instance_167 = new lib.CachedBmp_572();
	this.instance_167.setTransform(55.95,285.75,0.5,0.5);

	this.instance_168 = new lib.CachedBmp_571();
	this.instance_168.setTransform(74.7,232.05,0.5,0.5);

	this.instance_169 = new lib.CachedBmp_673();
	this.instance_169.setTransform(34.85,118.05,0.5,0.5);

	this.instance_170 = new lib.btnYa7();
	this.instance_170.setTransform(706.3,662.4,1,1,0,0,0,57.6,18);

	this.instance_171 = new lib.btnTidak7();
	this.instance_171.setTransform(575.4,662.4,1,1,0,0,0,57.6,18);

	this.instance_172 = new lib.CachedBmp_586();
	this.instance_172.setTransform(436.45,589.15,0.5,0.5);

	this.instance_173 = new lib.CachedBmp_585();
	this.instance_173.setTransform(683.25,312.95,0.5,0.5);

	this.instance_174 = new lib.CachedBmp_584();
	this.instance_174.setTransform(644.75,248,0.5,0.5);

	this.instance_175 = new lib.CachedBmp_583();
	this.instance_175.setTransform(215.1,483.9,0.5,0.5);

	this.instance_176 = new lib.CachedBmp_582();
	this.instance_176.setTransform(380.35,483.9,0.5,0.5);

	this.instance_177 = new lib.CachedBmp_581();
	this.instance_177.setTransform(47.75,483.9,0.5,0.5);

	this.instance_178 = new lib.CachedBmp_580();
	this.instance_178.setTransform(367.85,349.35,0.5,0.5);

	this.instance_179 = new lib.CachedBmp_579();
	this.instance_179.setTransform(198.9,349.35,0.5,0.5);

	this.instance_180 = new lib.CachedBmp_578();
	this.instance_180.setTransform(56.3,349.8,0.5,0.5);

	this.instance_181 = new lib.CachedBmp_577();
	this.instance_181.setTransform(32.1,304.85,0.5,0.5);

	this.instance_182 = new lib.CachedBmp_576();
	this.instance_182.setTransform(62.7,243.65,0.5,0.5);

	this.btnbacknikah1 = new lib.btnbacknikah1();
	this.btnbacknikah1.name = "btnbacknikah1";
	this.btnbacknikah1.setTransform(194,164,1,1,0,0,0,44,44);

	this.btnhomenikah1 = new lib.btnhomenikah1();
	this.btnhomenikah1.name = "btnhomenikah1";
	this.btnhomenikah1.setTransform(82,167,1,1,0,0,0,44,44);

	this.instance_183 = new lib.homenikah1();
	this.instance_183.setTransform(38,123,0.1913,0.1868);

	this.instance_184 = new lib.backnikah1();
	this.instance_184.setTransform(150,120,0.1876,0.1807);

	this.btnnext8 = new lib.btnnext8();
	this.btnnext8.name = "btnnext8";
	this.btnnext8.setTransform(1230.9,665.5,1,1,0,0,0,80.5,23.2);

	this.instance_185 = new lib.CachedBmp_591();
	this.instance_185.setTransform(1462.6,483.25,0.5,0.5);

	this.instance_186 = new lib.CachedBmp_590();
	this.instance_186.setTransform(73.15,404.3,0.5,0.5);

	this.instance_187 = new lib.CachedBmp_589();
	this.instance_187.setTransform(54.4,292.6,0.5,0.5);

	this.instance_188 = new lib.CachedBmp_588();
	this.instance_188.setTransform(73.15,250.9,0.5,0.5);

	this.instance_189 = new lib.CachedBmp_709();
	this.instance_189.setTransform(33.3,124.9,0.5,0.5);

	this.btnbacknikah2 = new lib.btnbacknikah2();
	this.btnbacknikah2.name = "btnbacknikah2";
	this.btnbacknikah2.setTransform(196,169,1,1,0,0,0,44,44);

	this.btnhomenikah2 = new lib.btnhomenikah2();
	this.btnhomenikah2.name = "btnhomenikah2";
	this.btnhomenikah2.setTransform(82,169,1,1,0,0,0,44,44);

	this.btnYa8 = new lib.btnYa8();
	this.btnYa8.name = "btnYa8";
	this.btnYa8.setTransform(708.55,666.3,1,1,0,0,0,57.6,18);

	this.btnTidak8 = new lib.btnTidak8();
	this.btnTidak8.name = "btnTidak8";
	this.btnTidak8.setTransform(577.65,666.3,1,1,0,0,0,57.6,18);

	this.instance_190 = new lib.DesainlogountukPBB();
	this.instance_190.setTransform(423,357,0.1079,0.128);

	this.instance_191 = new lib.CachedBmp_603();
	this.instance_191.setTransform(438.7,593.05,0.5,0.5);

	this.instance_192 = new lib.CachedBmp_602();
	this.instance_192.setTransform(685.5,302.2,0.5,0.5);

	this.instance_193 = new lib.CachedBmp_601();
	this.instance_193.setTransform(647,251.9,0.5,0.5);

	this.instance_194 = new lib.CachedBmp_600();
	this.instance_194.setTransform(222.55,487.8,0.5,0.5);

	this.instance_195 = new lib.CachedBmp_599();
	this.instance_195.setTransform(391.5,487.8,0.5,0.5);

	this.instance_196 = new lib.CachedBmp_598();
	this.instance_196.setTransform(50,487.8,0.5,0.5);

	this.instance_197 = new lib.CachedBmp_597();
	this.instance_197.setTransform(387.15,353.25,0.5,0.5);

	this.instance_198 = new lib.CachedBmp_596();
	this.instance_198.setTransform(201.15,353.25,0.5,0.5);

	this.instance_199 = new lib.CachedBmp_595();
	this.instance_199.setTransform(58.55,353.7,0.5,0.5);

	this.instance_200 = new lib.CachedBmp_594();
	this.instance_200.setTransform(34.35,308.75,0.5,0.5);

	this.instance_201 = new lib.CachedBmp_593();
	this.instance_201.setTransform(64.95,247.55,0.5,0.5);

	this.btnback9 = new lib.btnback9();
	this.btnback9.name = "btnback9";
	this.btnback9.setTransform(194,167,1,1,0,0,0,44,44);

	this.btnhome9 = new lib.btnhome9();
	this.btnhome9.name = "btnhome9";
	this.btnhome9.setTransform(74,167,1,1,0,0,0,44,44);

	this.btnnext9 = new lib.btnnext9();
	this.btnnext9.name = "btnnext9";
	this.btnnext9.setTransform(1226.85,661.65,1,1,0,0,0,80.5,23.2);

	this.instance_202 = new lib.CachedBmp_608();
	this.instance_202.setTransform(1458.55,479.4,0.5,0.5);

	this.instance_203 = new lib.CachedBmp_607();
	this.instance_203.setTransform(69.1,400.45,0.5,0.5);

	this.instance_204 = new lib.CachedBmp_606();
	this.instance_204.setTransform(50.35,288.75,0.5,0.5);

	this.instance_205 = new lib.CachedBmp_605();
	this.instance_205.setTransform(69.1,235.05,0.5,0.5);

	this.instance_206 = new lib.CachedBmp_604();
	this.instance_206.setTransform(29.25,121.05,0.5,0.5);

	this.btnYa9 = new lib.btnYa9();
	this.btnYa9.name = "btnYa9";
	this.btnYa9.setTransform(711.75,668.1,1,1,0,0,0,57.6,18);

	this.btnTidak9 = new lib.btnTidak9();
	this.btnTidak9.name = "btnTidak9";
	this.btnTidak9.setTransform(580.85,668.1,1,1,0,0,0,57.6,18);

	this.instance_207 = new lib.materai10ribu();
	this.instance_207.setTransform(423,356,0.1079,0.128);

	this.instance_208 = new lib.CachedBmp_620();
	this.instance_208.setTransform(441.9,594.85,0.5,0.5);

	this.instance_209 = new lib.CachedBmp_619();
	this.instance_209.setTransform(688.7,304,0.5,0.5);

	this.instance_210 = new lib.CachedBmp_618();
	this.instance_210.setTransform(650.2,253.7,0.5,0.5);

	this.instance_211 = new lib.CachedBmp_617();
	this.instance_211.setTransform(225.75,489.6,0.5,0.5);

	this.instance_212 = new lib.CachedBmp_616();
	this.instance_212.setTransform(390.35,489.6,0.5,0.5);

	this.instance_213 = new lib.CachedBmp_615();
	this.instance_213.setTransform(53.2,489.6,0.5,0.5);

	this.instance_214 = new lib.CachedBmp_614();
	this.instance_214.setTransform(390.35,355.05,0.5,0.5);

	this.instance_215 = new lib.CachedBmp_613();
	this.instance_215.setTransform(204.35,355.05,0.5,0.5);

	this.instance_216 = new lib.CachedBmp_612();
	this.instance_216.setTransform(61.75,355.5,0.5,0.5);

	this.instance_217 = new lib.CachedBmp_611();
	this.instance_217.setTransform(37.55,310.55,0.5,0.5);

	this.instance_218 = new lib.CachedBmp_610();
	this.instance_218.setTransform(68.15,249.35,0.5,0.5);

	this.instance_219 = new lib.CachedBmp_609();
	this.instance_219.setTransform(37.05,124.1,0.5,0.5);

	this.btnnext10 = new lib.btnnext10();
	this.btnnext10.name = "btnnext10";
	this.btnnext10.setTransform(1228.5,662.7,1,1,0,0,0,80.5,23.2);

	this.backsktm1 = new lib.backsktm1_1();
	this.backsktm1.name = "backsktm1";
	this.backsktm1.setTransform(194,168,1,1,0,0,0,44,44);

	this.homesktm1 = new lib.homesktm1_1();
	this.homesktm1.name = "homesktm1";
	this.homesktm1.setTransform(75,168,1,1,0,0,0,44,44);

	this.instance_220 = new lib.CachedBmp_625();
	this.instance_220.setTransform(1460.2,480.45,0.5,0.5);

	this.instance_221 = new lib.CachedBmp_624();
	this.instance_221.setTransform(70.75,401.5,0.5,0.5);

	this.instance_222 = new lib.CachedBmp_623();
	this.instance_222.setTransform(52,289.8,0.5,0.5);

	this.instance_223 = new lib.CachedBmp_622();
	this.instance_223.setTransform(70.75,236.1,0.5,0.5);

	this.btnback10 = new lib.btnback10();
	this.btnback10.name = "btnback10";
	this.btnback10.setTransform(194,167,1,1,0,0,0,44,44);

	this.btnhome10 = new lib.btnhome10();
	this.btnhome10.name = "btnhome10";
	this.btnhome10.setTransform(80,167,1,1,0,0,0,44,44);

	this.btnYa10 = new lib.btnYa10();
	this.btnYa10.name = "btnYa10";
	this.btnYa10.setTransform(704.85,664.5,1,1,0,0,0,57.6,18);

	this.btnTidak10 = new lib.btnTidak10();
	this.btnTidak10.name = "btnTidak10";
	this.btnTidak10.setTransform(573.95,664.5,1,1,0,0,0,57.6,18);

	this.instance_224 = new lib.CachedBmp_637();
	this.instance_224.setTransform(435,591.25,0.5,0.5);

	this.instance_225 = new lib.CachedBmp_636();
	this.instance_225.setTransform(681.8,286,0.5,0.5);

	this.instance_226 = new lib.CachedBmp_635();
	this.instance_226.setTransform(643.3,250.1,0.5,0.5);

	this.instance_227 = new lib.CachedBmp_634();
	this.instance_227.setTransform(218.85,486,0.5,0.5);

	this.instance_228 = new lib.CachedBmp_633();
	this.instance_228.setTransform(404.85,486,0.5,0.5);

	this.instance_229 = new lib.CachedBmp_632();
	this.instance_229.setTransform(46.3,486,0.5,0.5);

	this.instance_230 = new lib.CachedBmp_631();
	this.instance_230.setTransform(383.45,351.45,0.5,0.5);

	this.instance_231 = new lib.CachedBmp_630();
	this.instance_231.setTransform(197.45,351.45,0.5,0.5);

	this.instance_232 = new lib.CachedBmp_629();
	this.instance_232.setTransform(54.85,351.9,0.5,0.5);

	this.instance_233 = new lib.CachedBmp_628();
	this.instance_233.setTransform(30.65,306.95,0.5,0.5);

	this.instance_234 = new lib.CachedBmp_627();
	this.instance_234.setTransform(61.25,245.75,0.5,0.5);

	this.btnnext11 = new lib.btnnext11();
	this.btnnext11.name = "btnnext11";
	this.btnnext11.setTransform(1226.05,667.6,1,1,0,0,0,80.5,23.2);

	this.instance_235 = new lib.CachedBmp_641();
	this.instance_235.setTransform(68.3,406.4,0.5,0.5);

	this.instance_236 = new lib.CachedBmp_640();
	this.instance_236.setTransform(49.55,294.7,0.5,0.5);

	this.instance_237 = new lib.CachedBmp_639();
	this.instance_237.setTransform(68.3,241,0.5,0.5);

	this.btnYa11 = new lib.btnYa11();
	this.btnYa11.name = "btnYa11";
	this.btnYa11.setTransform(707.55,667.8,1,1,0,0,0,57.6,18);

	this.btnTidak11 = new lib.btnTidak11();
	this.btnTidak11.name = "btnTidak11";
	this.btnTidak11.setTransform(576.65,667.8,1,1,0,0,0,57.6,18);

	this.instance_238 = new lib.CachedBmp_655();
	this.instance_238.setTransform(501.6,488.1,0.5,0.5);

	this.instance_239 = new lib.CachedBmp_654();
	this.instance_239.setTransform(497.65,354.75,0.5,0.5);

	this.instance_240 = new lib.CachedBmp_653();
	this.instance_240.setTransform(437.7,594.55,0.5,0.5);

	this.instance_241 = new lib.CachedBmp_652();
	this.instance_241.setTransform(684.5,317.6,0.5,0.5);

	this.instance_242 = new lib.CachedBmp_651();
	this.instance_242.setTransform(646,253.4,0.5,0.5);

	this.instance_243 = new lib.CachedBmp_650();
	this.instance_243.setTransform(207.7,489.3,0.5,0.5);

	this.instance_244 = new lib.CachedBmp_649();
	this.instance_244.setTransform(364.05,489.1,0.5,0.5);

	this.instance_245 = new lib.CachedBmp_648();
	this.instance_245.setTransform(49,489.3,0.5,0.5);

	this.instance_246 = new lib.CachedBmp_647();
	this.instance_246.setTransform(352.2,354.75,0.5,0.5);

	this.instance_247 = new lib.CachedBmp_646();
	this.instance_247.setTransform(200.15,354.75,0.5,0.5);

	this.instance_248 = new lib.CachedBmp_645();
	this.instance_248.setTransform(57.55,355.2,0.5,0.5);

	this.instance_249 = new lib.CachedBmp_644();
	this.instance_249.setTransform(33.35,310.25,0.5,0.5);

	this.instance_250 = new lib.CachedBmp_643();
	this.instance_250.setTransform(63.95,249.05,0.5,0.5);

	this.btnback12 = new lib.btnback12();
	this.btnback12.name = "btnback12";
	this.btnback12.setTransform(189,172,1,1,0,0,0,44,44);

	this.btnhome12 = new lib.btnhome12();
	this.btnhome12.name = "btnhome12";
	this.btnhome12.setTransform(84,172,1,1,0,0,0,44,44);

	this.btnnext12 = new lib.btnnext12();
	this.btnnext12.name = "btnnext12";
	this.btnnext12.setTransform(1230.05,667.2,1,1,0,0,0,80.5,23.2);

	this.instance_251 = new lib.CachedBmp_660();
	this.instance_251.setTransform(1461.75,484.95,0.5,0.5);

	this.instance_252 = new lib.CachedBmp_659();
	this.instance_252.setTransform(72.3,406,0.5,0.5);

	this.instance_253 = new lib.CachedBmp_658();
	this.instance_253.setTransform(53.55,294.3,0.5,0.5);

	this.instance_254 = new lib.CachedBmp_657();
	this.instance_254.setTransform(72.3,244.3,0.5,0.5);

	this.btnYa12 = new lib.btnYa12();
	this.btnYa12.name = "btnYa12";
	this.btnYa12.setTransform(709.1,662.3,1,1,0,0,0,57.6,18);

	this.btnTidak12 = new lib.btnTidak12();
	this.btnTidak12.name = "btnTidak12";
	this.btnTidak12.setTransform(578.2,662.3,1,1,0,0,0,57.6,18);

	this.instance_255 = new lib.CachedBmp_672();
	this.instance_255.setTransform(439.25,589.05,0.5,0.5);

	this.instance_256 = new lib.CachedBmp_671();
	this.instance_256.setTransform(686.05,312.1,0.5,0.5);

	this.instance_257 = new lib.CachedBmp_670();
	this.instance_257.setTransform(647.55,247.9,0.5,0.5);

	this.instance_258 = new lib.CachedBmp_669();
	this.instance_258.setTransform(236.7,483.8,0.5,0.5);

	this.instance_259 = new lib.CachedBmp_668();
	this.instance_259.setTransform(447,483.8,0.5,0.5);

	this.instance_260 = new lib.CachedBmp_667();
	this.instance_260.setTransform(50.55,483.8,0.5,0.5);

	this.instance_261 = new lib.CachedBmp_666();
	this.instance_261.setTransform(417.45,349.25,0.5,0.5);

	this.instance_262 = new lib.CachedBmp_665();
	this.instance_262.setTransform(236.7,349.25,0.5,0.5);

	this.instance_263 = new lib.CachedBmp_664();
	this.instance_263.setTransform(59.1,349.7,0.5,0.5);

	this.instance_264 = new lib.CachedBmp_663();
	this.instance_264.setTransform(34.9,304.75,0.5,0.5);

	this.instance_265 = new lib.CachedBmp_662();
	this.instance_265.setTransform(65.5,243.55,0.5,0.5);

	this.btnnext13 = new lib.btnnext13();
	this.btnnext13.name = "btnnext13";
	this.btnnext13.setTransform(1230.05,669.45,1,1,0,0,0,80.5,23.2);

	this.btnbackdaerah = new lib.btnbackdaerah();
	this.btnbackdaerah.name = "btnbackdaerah";
	this.btnbackdaerah.setTransform(194,175,1,1,0,0,0,44,44);

	this.btnhomedaerah = new lib.btnhomedaerah();
	this.btnhomedaerah.name = "btnhomedaerah";
	this.btnhomedaerah.setTransform(83,175,1,1,0,0,0,44,44);

	this.instance_266 = new lib.CachedBmp_676();
	this.instance_266.setTransform(72.3,425.45,0.5,0.5);

	this.instance_267 = new lib.CachedBmp_675();
	this.instance_267.setTransform(53.55,307.05,0.5,0.5);

	this.instance_268 = new lib.CachedBmp_674();
	this.instance_268.setTransform(72.3,258.95,0.5,0.5);

	this.btnYa13 = new lib.btnYa13();
	this.btnYa13.name = "btnYa13";
	this.btnYa13.setTransform(709.05,670.05,1,1,0,0,0,57.6,18);

	this.btnTidak13 = new lib.btnTidak13();
	this.btnTidak13.name = "btnTidak13";
	this.btnTidak13.setTransform(578.15,670.05,1,1,0,0,0,57.6,18);

	this.instance_269 = new lib.CachedBmp_690();
	this.instance_269.setTransform(366.8,490.1,0.5,0.5);

	this.instance_270 = new lib.CachedBmp_689();
	this.instance_270.setTransform(509.35,357,0.5,0.5);

	this.instance_271 = new lib.CachedBmp_688();
	this.instance_271.setTransform(439.2,596.8,0.5,0.5);

	this.instance_272 = new lib.CachedBmp_687();
	this.instance_272.setTransform(686,319.85,0.5,0.5);

	this.instance_273 = new lib.CachedBmp_686();
	this.instance_273.setTransform(647.5,255.65,0.5,0.5);

	this.instance_274 = new lib.CachedBmp_685();
	this.instance_274.setTransform(209.2,491.55,0.5,0.5);

	this.instance_275 = new lib.CachedBmp_684();
	this.instance_275.setTransform(528.15,491.55,0.5,0.5);

	this.instance_276 = new lib.CachedBmp_683();
	this.instance_276.setTransform(50.5,491.55,0.5,0.5);

	this.instance_277 = new lib.CachedBmp_682();
	this.instance_277.setTransform(353.7,357,0.5,0.5);

	this.instance_278 = new lib.CachedBmp_681();
	this.instance_278.setTransform(201.65,357,0.5,0.5);

	this.instance_279 = new lib.CachedBmp_680();
	this.instance_279.setTransform(59.05,357.45,0.5,0.5);

	this.instance_280 = new lib.CachedBmp_679();
	this.instance_280.setTransform(34.85,312.5,0.5,0.5);

	this.instance_281 = new lib.CachedBmp_678();
	this.instance_281.setTransform(65.45,261.3,0.5,0.5);

	this.btnbackdtks = new lib.btnbackdtks();
	this.btnbackdtks.name = "btnbackdtks";
	this.btnbackdtks.setTransform(184,176,1,1,0,0,0,44,44);

	this.btnhomedtks = new lib.btnhomedtks();
	this.btnhomedtks.name = "btnhomedtks";
	this.btnhomedtks.setTransform(80,176,1,1,0,0,0,44,44);

	this.btnnext14 = new lib.btnnext14();
	this.btnnext14.name = "btnnext14";
	this.btnnext14.setTransform(1225.55,671.05,1,1,0,0,0,80.5,23.2);

	this.instance_282 = new lib.CachedBmp_694();
	this.instance_282.setTransform(67.8,427.05,0.5,0.5);

	this.instance_283 = new lib.CachedBmp_693();
	this.instance_283.setTransform(49.05,318.75,0.5,0.5);

	this.instance_284 = new lib.CachedBmp_692();
	this.instance_284.setTransform(67.8,248.8,0.5,0.5);

	this.btnYa14 = new lib.btnYa14();
	this.btnYa14.name = "btnYa14";
	this.btnYa14.setTransform(712.8,671.95,1,1,0,0,0,57.6,18);

	this.btnTidak14 = new lib.btnTidak14();
	this.btnTidak14.name = "btnTidak14";
	this.btnTidak14.setTransform(581.9,671.95,1,1,0,0,0,57.6,18);

	this.instance_285 = new lib.CachedBmp_708();
	this.instance_285.setTransform(511.35,492,0.5,0.5);

	this.instance_286 = new lib.CachedBmp_707();
	this.instance_286.setTransform(502.9,358.9,0.5,0.5);

	this.instance_287 = new lib.CachedBmp_706();
	this.instance_287.setTransform(442.95,598.7,0.5,0.5);

	this.instance_288 = new lib.CachedBmp_705();
	this.instance_288.setTransform(689.75,321.75,0.5,0.5);

	this.instance_289 = new lib.CachedBmp_704();
	this.instance_289.setTransform(651.25,257.55,0.5,0.5);

	this.instance_290 = new lib.CachedBmp_703();
	this.instance_290.setTransform(212.95,493.45,0.5,0.5);

	this.instance_291 = new lib.CachedBmp_702();
	this.instance_291.setTransform(370.55,493.45,0.5,0.5);

	this.instance_292 = new lib.CachedBmp_701();
	this.instance_292.setTransform(54.25,493.45,0.5,0.5);

	this.instance_293 = new lib.CachedBmp_700();
	this.instance_293.setTransform(357.45,358.9,0.5,0.5);

	this.instance_294 = new lib.CachedBmp_699();
	this.instance_294.setTransform(205.4,358.9,0.5,0.5);

	this.instance_295 = new lib.CachedBmp_698();
	this.instance_295.setTransform(62.8,359.35,0.5,0.5);

	this.instance_296 = new lib.CachedBmp_697();
	this.instance_296.setTransform(38.6,314.4,0.5,0.5);

	this.instance_297 = new lib.CachedBmp_696();
	this.instance_297.setTransform(62.8,253.2,0.5,0.5);

	this.btnnext15 = new lib.btnnext15();
	this.btnnext15.name = "btnnext15";
	this.btnnext15.setTransform(1230.25,672.35,1,1,0,0,0,80.5,23.2);

	this.btnbackskck = new lib.btnbackskck();
	this.btnbackskck.name = "btnbackskck";
	this.btnbackskck.setTransform(194,177.75,1,1,0,0,0,44,44);

	this.btnhomeskck = new lib.btnhomeskck();
	this.btnhomeskck.name = "btnhomeskck";
	this.btnhomeskck.setTransform(83.45,177.75,1,1,0,0,0,44,44);

	this.instance_298 = new lib.CachedBmp_712();
	this.instance_298.setTransform(72.5,428.35,0.5,0.5);

	this.instance_299 = new lib.CachedBmp_711();
	this.instance_299.setTransform(53.75,312.15,0.5,0.5);

	this.instance_300 = new lib.CachedBmp_710();
	this.instance_300.setTransform(72.5,250.1,0.5,0.5);

	this.btnYa15 = new lib.btnYa15();
	this.btnYa15.name = "btnYa15";
	this.btnYa15.setTransform(703.9,675.9,1,1,0,0,0,57.6,18);

	this.btnTidak15 = new lib.btnTidak15();
	this.btnTidak15.name = "btnTidak15";
	this.btnTidak15.setTransform(573,675.9,1,1,0,0,0,57.6,18);

	this.instance_301 = new lib.CachedBmp_726();
	this.instance_301.setTransform(502.45,495.95,0.5,0.5);

	this.instance_302 = new lib.CachedBmp_725();
	this.instance_302.setTransform(494,362.85,0.5,0.5);

	this.instance_303 = new lib.CachedBmp_724();
	this.instance_303.setTransform(434.05,602.65,0.5,0.5);

	this.instance_304 = new lib.CachedBmp_723();
	this.instance_304.setTransform(680.85,325.7,0.5,0.5);

	this.instance_305 = new lib.CachedBmp_722();
	this.instance_305.setTransform(642.35,261.5,0.5,0.5);

	this.instance_306 = new lib.CachedBmp_721();
	this.instance_306.setTransform(204.05,497.4,0.5,0.5);

	this.instance_307 = new lib.CachedBmp_720();
	this.instance_307.setTransform(361.65,497.4,0.5,0.5);

	this.instance_308 = new lib.CachedBmp_719();
	this.instance_308.setTransform(45.35,497.4,0.5,0.5);

	this.instance_309 = new lib.CachedBmp_718();
	this.instance_309.setTransform(348.55,362.85,0.5,0.5);

	this.instance_310 = new lib.CachedBmp_717();
	this.instance_310.setTransform(196.5,362.85,0.5,0.5);

	this.instance_311 = new lib.CachedBmp_716();
	this.instance_311.setTransform(53.9,363.3,0.5,0.5);

	this.instance_312 = new lib.CachedBmp_715();
	this.instance_312.setTransform(29.7,318.35,0.5,0.5);

	this.instance_313 = new lib.CachedBmp_714();
	this.instance_313.setTransform(53.9,257.15,0.5,0.5);

	this.btnbackberkas = new lib.btnbackberkas();
	this.btnbackberkas.name = "btnbackberkas";
	this.btnbackberkas.setTransform(194,173,1,1,0,0,0,44,44);

	this.btnhomeberkas = new lib.btnhomeberkas();
	this.btnhomeberkas.name = "btnhomeberkas";
	this.btnhomeberkas.setTransform(83,173,1,1,0,0,0,44,44);

	this.btnnext16 = new lib.btnnext16();
	this.btnnext16.name = "btnnext16";
	this.btnnext16.setTransform(1231.9,667.95,1,1,0,0,0,80.5,23.2);

	this.instance_314 = new lib.CachedBmp_730();
	this.instance_314.setTransform(74.15,423.95,0.5,0.5);

	this.instance_315 = new lib.CachedBmp_729();
	this.instance_315.setTransform(55.4,320.45,0.5,0.5);

	this.instance_316 = new lib.CachedBmp_728();
	this.instance_316.setTransform(74.15,257.45,0.5,0.5);

	this.btnback16 = new lib.btnback16();
	this.btnback16.name = "btnback16";
	this.btnback16.setTransform(200,167,1,1,0,0,0,44,44);

	this.btnhome16 = new lib.btnhome16();
	this.btnhome16.name = "btnhome16";
	this.btnhome16.setTransform(77,167,1,1,0,0,0,44,44);

	this.btnYa16 = new lib.btnYa16();
	this.btnYa16.name = "btnYa16";
	this.btnYa16.setTransform(706.95,668.95,1,1,0,0,0,57.6,18);

	this.btnTidak16 = new lib.btnTidak16();
	this.btnTidak16.name = "btnTidak16";
	this.btnTidak16.setTransform(576.05,668.95,1,1,0,0,0,57.6,18);

	this.instance_317 = new lib.CachedBmp_744();
	this.instance_317.setTransform(505.5,489,0.5,0.5);

	this.instance_318 = new lib.CachedBmp_743();
	this.instance_318.setTransform(497.05,355.9,0.5,0.5);

	this.instance_319 = new lib.CachedBmp_742();
	this.instance_319.setTransform(437.1,595.7,0.5,0.5);

	this.instance_320 = new lib.CachedBmp_741();
	this.instance_320.setTransform(683.9,318.75,0.5,0.5);

	this.instance_321 = new lib.CachedBmp_740();
	this.instance_321.setTransform(645.4,254.55,0.5,0.5);

	this.instance_322 = new lib.CachedBmp_739();
	this.instance_322.setTransform(207.1,490.45,0.5,0.5);

	this.instance_323 = new lib.CachedBmp_738();
	this.instance_323.setTransform(364.7,490.45,0.5,0.5);

	this.instance_324 = new lib.CachedBmp_737();
	this.instance_324.setTransform(48.4,490.45,0.5,0.5);

	this.instance_325 = new lib.CachedBmp_736();
	this.instance_325.setTransform(351.6,355.9,0.5,0.5);

	this.instance_326 = new lib.CachedBmp_735();
	this.instance_326.setTransform(199.55,355.9,0.5,0.5);

	this.instance_327 = new lib.CachedBmp_734();
	this.instance_327.setTransform(56.95,356.35,0.5,0.5);

	this.instance_328 = new lib.CachedBmp_733();
	this.instance_328.setTransform(32.75,311.4,0.5,0.5);

	this.instance_329 = new lib.CachedBmp_732();
	this.instance_329.setTransform(56.95,260.2,0.5,0.5);

	this.btnbackbeda = new lib.btnbackbeda();
	this.btnbackbeda.name = "btnbackbeda";
	this.btnbackbeda.setTransform(189,175.45,0.1876,0.1807,0,0,0,234.5,243.5);

	this.btnhomebeda = new lib.btnhomebeda();
	this.btnhomebeda.name = "btnhomebeda";
	this.btnhomebeda.setTransform(80.15,175.45,0.1913,0.1868,0,0,0,230.2,235.5);

	this.btnnext17 = new lib.btnnext17();
	this.btnnext17.name = "btnnext17";
	this.btnnext17.setTransform(1227.8,670.05,1,1,0,0,0,80.5,23.2);

	this.instance_330 = new lib.CachedBmp_748();
	this.instance_330.setTransform(70.05,426.05,0.5,0.5);

	this.instance_331 = new lib.CachedBmp_747();
	this.instance_331.setTransform(51.3,307.65,0.5,0.5);

	this.instance_332 = new lib.CachedBmp_746();
	this.instance_332.setTransform(70.05,247.8,0.5,0.5);

	this.btnback17 = new lib.btnback17();
	this.btnback17.name = "btnback17";
	this.btnback17.setTransform(200,167,1,1,0,0,0,44,44);

	this.btnhome17 = new lib.btnhome17();
	this.btnhome17.name = "btnhome17";
	this.btnhome17.setTransform(79,167,1,1,0,0,0,44,44);

	this.btnYa17 = new lib.btnYa17();
	this.btnYa17.name = "btnYa17";
	this.btnYa17.setTransform(709,668.9,1,1,0,0,0,57.6,18);

	this.btnTidak17 = new lib.btnTidak17();
	this.btnTidak17.name = "btnTidak17";
	this.btnTidak17.setTransform(578.1,668.9,1,1,0,0,0,57.6,18);

	this.instance_333 = new lib.CachedBmp_764();
	this.instance_333.setTransform(551.25,453.9,0.5,0.5);

	this.instance_334 = new lib.CachedBmp_763();
	this.instance_334.setTransform(543.5,355.85,0.5,0.5);

	this.instance_335 = new lib.CachedBmp_762();
	this.instance_335.setTransform(422.05,453.9,0.5,0.5);

	this.instance_336 = new lib.CachedBmp_761();
	this.instance_336.setTransform(414.35,355.85,0.5,0.5);

	this.instance_337 = new lib.CachedBmp_760();
	this.instance_337.setTransform(439.15,595.65,0.5,0.5);

	this.instance_338 = new lib.CachedBmp_759();
	this.instance_338.setTransform(685.95,318.7,0.5,0.5);

	this.instance_339 = new lib.CachedBmp_758();
	this.instance_339.setTransform(647.45,254.5,0.5,0.5);

	this.instance_340 = new lib.CachedBmp_757();
	this.instance_340.setTransform(145,453.9,0.5,0.5);

	this.instance_341 = new lib.CachedBmp_756();
	this.instance_341.setTransform(281.2,453.9,0.5,0.5);

	this.instance_342 = new lib.CachedBmp_755();
	this.instance_342.setTransform(34.8,453.9,0.5,0.5);

	this.instance_343 = new lib.CachedBmp_754();
	this.instance_343.setTransform(281.2,355.85,0.5,0.5);

	this.instance_344 = new lib.CachedBmp_753();
	this.instance_344.setTransform(156.2,355.85,0.5,0.5);

	this.instance_345 = new lib.CachedBmp_752();
	this.instance_345.setTransform(37.6,355.85,0.5,0.5);

	this.instance_346 = new lib.CachedBmp_751();
	this.instance_346.setTransform(34.8,311.35,0.5,0.5);

	this.instance_347 = new lib.CachedBmp_750();
	this.instance_347.setTransform(59,250.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.faceb}]}).to({state:[{t:this.instance_65},{t:this.btnhome},{t:this.btnkembali},{t:this.btnkk_1},{t:this.btnpindahkk},{t:this.instance_64},{t:this.text,p:{x:1224.8,y:211.6,text:"Layanan Publik",font:"30px 'Arial Rounded MT Bold'",lineHeight:36.75,lineWidth:247}},{t:this.btnkk},{t:this.instance_63},{t:this.btnkelahiran},{t:this.instance_62},{t:this.btnkematian},{t:this.instance_61},{t:this.btnktp},{t:this.instance_60},{t:this.btnkia},{t:this.instance_59},{t:this.btnsku},{t:this.instance_58},{t:this.btnskm},{t:this.instance_57},{t:this.btnnikah},{t:this.instance_56},{t:this.btnbelumnikah},{t:this.instance_55},{t:this.btnsktm},{t:this.instance_54},{t:this.btndomisili},{t:this.instance_53},{t:this.btnbpjs},{t:this.instance_52},{t:this.btndtks},{t:this.instance_51},{t:this.btnberkas},{t:this.instance_50},{t:this.btnskck},{t:this.instance_49},{t:this.btnbeda},{t:this.instance_48}]},4).to({state:[{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.btnnext1},{t:this.text,p:{x:1208.1,y:657.7,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:139}}]},5).to({state:[{t:this.instance_82},{t:this.instance_81},{t:this.instance_80},{t:this.instance_79,p:{x:74,y:349,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:232,y:352,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.instance_74,p:{x:394,y:352}},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.instance_70},{t:this.instance_69},{t:this.text_2},{t:this.btnTidak1},{t:this.text_1,p:{x:551.3,y:660.2,lineWidth:122}},{t:this.btnYa1},{t:this.text,p:{x:738.9,y:658.4,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:122}}]},2).to({state:[]},3).to({state:[{t:this.instance_86,p:{x:31.6,y:128}},{t:this.instance_85},{t:this.instance_84},{t:this.instance_83},{t:this.btnhome3},{t:this.btnnext2},{t:this.text,p:{x:1229.25,y:656.6,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}},{t:this.btnback3}]},26).to({state:[{t:this.instance_98,p:{y:117.5,x:29.25}},{t:this.instance_97},{t:this.instance_96},{t:this.instance_79,p:{x:76,y:348,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:403,y:351,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_95},{t:this.instance_94},{t:this.instance_93},{t:this.instance_74,p:{x:233,y:351}},{t:this.instance_92},{t:this.instance_91},{t:this.instance_90},{t:this.instance_89},{t:this.instance_88},{t:this.instance_87},{t:this.btnTidak2},{t:this.text_1,p:{x:574.55,y:649.6,lineWidth:94}},{t:this.btnYa2},{t:this.text,p:{x:705.35,y:649.6,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}}]},3).to({state:[{t:this.instance_102},{t:this.instance_101},{t:this.instance_100},{t:this.instance_99},{t:this.btnhomektp1},{t:this.btnbackktp1},{t:this.btnnext3},{t:this.text,p:{x:1225.05,y:659.55,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}}]},2).to({state:[{t:this.instance_98,p:{y:124.85,x:29.25}},{t:this.instance_112},{t:this.instance_111},{t:this.instance_79,p:{x:76,y:355,scaleX:0.2061,scaleY:0.241}},{t:this.instance_110},{t:this.instance_109},{t:this.instance_108},{t:this.instance_107},{t:this.instance_106},{t:this.instance_105},{t:this.instance_104},{t:this.instance_103,p:{x:243,y:355}},{t:this.btnTidak3},{t:this.text_1,p:{x:573.1,y:656.95,lineWidth:94}},{t:this.btnYa3},{t:this.text,p:{x:705.35,y:656.95,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}}]},3).to({state:[{t:this.instance_116},{t:this.instance_115},{t:this.instance_114},{t:this.instance_113},{t:this.btnnext4},{t:this.text,p:{x:1231.4,y:667.35,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:91}},{t:this.btnhomekia1},{t:this.btnbackkia1}]},2).to({state:[{t:this.instance_98,p:{y:123.6,x:35.7}},{t:this.instance_129},{t:this.instance_128},{t:this.instance_79,p:{x:82,y:354,scaleX:0.2061,scaleY:0.241}},{t:this.instance_127},{t:this.instance_126},{t:this.instance_125},{t:this.instance_124},{t:this.instance_123},{t:this.instance_122},{t:this.instance_121},{t:this.instance_120},{t:this.instance_119},{t:this.instance_118,p:{x:246,y:354,scaleX:0.1079,scaleY:0.128}},{t:this.instance_117,p:{x:422,y:354}},{t:this.btnTidak4},{t:this.btnYa4},{t:this.text_1,p:{x:581.4,y:655.5,lineWidth:94}},{t:this.text,p:{x:710.45,y:655.5,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}}]},3).to({state:[{t:this.instance_86,p:{x:33,y:129.7}},{t:this.instance_132},{t:this.instance_131},{t:this.instance_130},{t:this.btnnext5},{t:this.text,p:{x:1230.65,y:658.3,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}},{t:this.btnhomemati1},{t:this.btnbackmati1}]},2).to({state:[{t:this.instance_98,p:{y:125.5,x:28.05}},{t:this.instance_145},{t:this.instance_144},{t:this.instance_79,p:{x:75,y:356,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:220,y:359,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_143},{t:this.instance_142},{t:this.instance_141},{t:this.instance_140},{t:this.instance_139},{t:this.instance_138},{t:this.instance_137},{t:this.instance_136},{t:this.instance_135},{t:this.instance_134},{t:this.instance_133},{t:this.instance_117,p:{x:368,y:356}},{t:this.instance_118,p:{x:524,y:356,scaleX:0.1079,scaleY:0.128}},{t:this.btnTidak5},{t:this.btnYa5},{t:this.text_1,p:{x:572.9,y:657.4,lineWidth:94}},{t:this.text,p:{x:702.8,y:657.4,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}}]},3).to({state:[{t:this.instance_86,p:{x:28,y:128.15}},{t:this.instance_148},{t:this.instance_147},{t:this.instance_146},{t:this.btnhome6},{t:this.btnnext6},{t:this.text,p:{x:1225.65,y:656.75,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}},{t:this.btnback6}]},2).to({state:[{t:this.instance_164,p:{x:29.05,y:116.2}},{t:this.instance_163},{t:this.instance_162},{t:this.instance_79,p:{x:76,y:347,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:221,y:349,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_161},{t:this.instance_160},{t:this.instance_159},{t:this.instance_158},{t:this.instance_157},{t:this.instance_156},{t:this.instance_155},{t:this.instance_154},{t:this.instance_153},{t:this.instance_152},{t:this.instance_151},{t:this.instance_150,p:{x:369,y:349,scaleX:0.1079,scaleY:0.128}},{t:this.instance_149},{t:this.btnTidak6},{t:this.btnYa6},{t:this.text_1,p:{x:572.9,y:648.1,lineWidth:94}},{t:this.text,p:{x:703.8,y:648.1,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}},{t:this.btnhomesku2},{t:this.btnbacksku2}]},3).to({state:[{t:this.instance_169,p:{x:34.85,y:118.05}},{t:this.instance_168},{t:this.instance_167},{t:this.instance_166},{t:this.instance_165},{t:this.btnnext7},{t:this.text,p:{x:1232.5,y:646.65,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}}]},2).to({state:[{t:this.instance_98,p:{y:119.7,x:31.6}},{t:this.instance_182},{t:this.instance_181},{t:this.instance_79,p:{x:79,y:351,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:236,y:353,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_180},{t:this.instance_179},{t:this.instance_178},{t:this.instance_177},{t:this.instance_176},{t:this.instance_175},{t:this.instance_174},{t:this.instance_173},{t:this.instance_172},{t:this.instance_103,p:{x:403,y:353}},{t:this.instance_171},{t:this.instance_170},{t:this.text_1,p:{x:575.45,y:651.6,lineWidth:94}},{t:this.text,p:{x:709.15,y:651.6,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}}]},3).to({state:[{t:this.instance_189,p:{x:33.3,y:124.9}},{t:this.instance_188},{t:this.instance_187},{t:this.instance_186},{t:this.instance_185},{t:this.btnnext8},{t:this.text,p:{x:1230.95,y:653.5,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}},{t:this.instance_184},{t:this.instance_183},{t:this.btnhomenikah1},{t:this.btnbacknikah1}]},2).to({state:[{t:this.instance_98,p:{y:123.6,x:33.85}},{t:this.instance_201},{t:this.instance_200},{t:this.instance_79,p:{x:81,y:355,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:247,y:357,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_199},{t:this.instance_198},{t:this.instance_197},{t:this.instance_196},{t:this.instance_195},{t:this.instance_194},{t:this.instance_193},{t:this.instance_192},{t:this.instance_191},{t:this.instance_190,p:{x:423,y:357,scaleX:0.1079,scaleY:0.128}},{t:this.btnTidak8},{t:this.btnYa8},{t:this.text_1,p:{x:577.7,y:655.5,lineWidth:94}},{t:this.text,p:{x:711.4,y:655.5,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}},{t:this.btnhomenikah2},{t:this.btnbacknikah2}]},3).to({state:[{t:this.instance_206},{t:this.instance_205},{t:this.instance_204},{t:this.instance_203},{t:this.instance_202},{t:this.btnnext9},{t:this.text,p:{x:1226.9,y:649.65,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}},{t:this.btnhome9},{t:this.btnback9}]},2).to({state:[{t:this.instance_219},{t:this.instance_218},{t:this.instance_217},{t:this.instance_79,p:{x:85,y:356,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:251,y:358,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_216},{t:this.instance_215},{t:this.instance_214},{t:this.instance_213},{t:this.instance_212},{t:this.instance_211},{t:this.instance_210},{t:this.instance_209},{t:this.instance_208},{t:this.instance_207},{t:this.btnTidak9},{t:this.btnYa9},{t:this.text_1,p:{x:582.4,y:657.3,lineWidth:94}},{t:this.text,p:{x:711.8,y:657.3,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}}]},3).to({state:[{t:this.instance_86,p:{x:30.9,y:122.1}},{t:this.instance_223},{t:this.instance_222},{t:this.instance_221},{t:this.instance_220},{t:this.homesktm1},{t:this.backsktm1},{t:this.btnnext10},{t:this.text,p:{x:1228.55,y:650.7,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}}]},2).to({state:[{t:this.instance_98,p:{y:121.8,x:30.15}},{t:this.instance_234},{t:this.instance_233},{t:this.instance_79,p:{x:79,y:353,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:245,y:355,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_232},{t:this.instance_231},{t:this.instance_230},{t:this.instance_229},{t:this.instance_228},{t:this.instance_227},{t:this.instance_226},{t:this.instance_225},{t:this.instance_224},{t:this.instance_150,p:{x:435,y:355,scaleX:0.1079,scaleY:0.128}},{t:this.btnTidak10},{t:this.btnYa10},{t:this.text_1,p:{x:574,y:653.7,lineWidth:94}},{t:this.text,p:{x:704.9,y:653.7,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}},{t:this.btnhome10},{t:this.btnback10}]},3).to({state:[{t:this.instance_189,p:{x:28.45,y:127}},{t:this.instance_237},{t:this.instance_236},{t:this.instance_235},{t:this.btnnext11},{t:this.text,p:{x:1226.1,y:655.6,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}}]},2).to({state:[{t:this.instance_98,p:{y:125.1,x:32.85}},{t:this.instance_250},{t:this.instance_249},{t:this.instance_79,p:{x:82,y:357,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:230,y:357,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_248},{t:this.instance_247},{t:this.instance_246},{t:this.instance_245},{t:this.instance_244},{t:this.instance_243},{t:this.instance_242},{t:this.instance_241},{t:this.instance_240},{t:this.instance_239},{t:this.instance_238},{t:this.instance_190,p:{x:374,y:355,scaleX:0.1079,scaleY:0.128}},{t:this.instance_117,p:{x:524,y:357}},{t:this.btnTidak11},{t:this.btnYa11},{t:this.text_1,p:{x:576.7,y:657,lineWidth:94}},{t:this.text,p:{x:707.6,y:657,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}}]},3).to({state:[{t:this.instance_86,p:{x:32.45,y:126.6}},{t:this.instance_254},{t:this.instance_253},{t:this.instance_252},{t:this.instance_251},{t:this.btnnext12},{t:this.text,p:{x:1230.1,y:655.2,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}},{t:this.btnhome12},{t:this.btnback12}]},2).to({state:[{t:this.instance_98,p:{y:119.6,x:34.4}},{t:this.instance_265},{t:this.instance_264},{t:this.instance_79,p:{x:84,y:351,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:262,y:351,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_263},{t:this.instance_262},{t:this.instance_261},{t:this.instance_260},{t:this.instance_259},{t:this.instance_258},{t:this.instance_257},{t:this.instance_256},{t:this.instance_255},{t:this.instance_150,p:{x:447,y:349,scaleX:0.1079,scaleY:0.128}},{t:this.btnTidak12},{t:this.btnYa12},{t:this.text_1,p:{x:578.25,y:651.5,lineWidth:94}},{t:this.text,p:{x:709.15,y:651.5,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}}]},3).to({state:[{t:this.instance_169,p:{x:32.45,y:128.85}},{t:this.instance_268},{t:this.instance_267},{t:this.instance_266},{t:this.btnhomedaerah},{t:this.btnbackdaerah},{t:this.btnnext13},{t:this.text,p:{x:1230.1,y:657.45,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}}]},2).to({state:[{t:this.instance_164,p:{x:34.35,y:127.35}},{t:this.instance_281},{t:this.instance_280},{t:this.instance_79,p:{x:84,y:359,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:232,y:359,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_279},{t:this.instance_278},{t:this.instance_277},{t:this.instance_276},{t:this.instance_275},{t:this.instance_274},{t:this.instance_273},{t:this.instance_272},{t:this.instance_271},{t:this.instance_270},{t:this.instance_269},{t:this.instance_190,p:{x:537,y:357,scaleX:0.1079,scaleY:0.128}},{t:this.instance_150,p:{x:389,y:356,scaleX:0.1079,scaleY:0.128}},{t:this.btnTidak13},{t:this.btnYa13},{t:this.text_1,p:{x:577.05,y:659.25,lineWidth:94}},{t:this.text,p:{x:710.45,y:659.25,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}}]},3).to({state:[{t:this.instance_86,p:{x:27.95,y:130.45}},{t:this.instance_284},{t:this.instance_283},{t:this.instance_282},{t:this.btnnext14},{t:this.text,p:{x:1225.6,y:659.05,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}},{t:this.btnhomedtks},{t:this.btnbackdtks}]},2).to({state:[{t:this.instance_98,p:{y:129.25,x:38.1}},{t:this.instance_297},{t:this.instance_296},{t:this.instance_79,p:{x:88,y:361,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:236,y:361,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_295},{t:this.instance_294},{t:this.instance_293},{t:this.instance_292},{t:this.instance_291},{t:this.instance_290},{t:this.instance_289},{t:this.instance_288},{t:this.instance_287},{t:this.instance_286},{t:this.instance_285},{t:this.instance_150,p:{x:384,y:362,scaleX:0.1079,scaleY:0.128}},{t:this.instance_117,p:{x:535,y:362}},{t:this.btnTidak14},{t:this.btnYa14},{t:this.text_1,p:{x:583.9,y:661.15,lineWidth:94}},{t:this.text,p:{x:714.2,y:661.15,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}}]},3).to({state:[{t:this.instance_189,p:{x:32.65,y:131.75}},{t:this.instance_300},{t:this.instance_299},{t:this.instance_298},{t:this.btnhomeskck},{t:this.btnbackskck},{t:this.btnnext15},{t:this.text,p:{x:1230.3,y:660.35,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}}]},2).to({state:[{t:this.instance_98,p:{y:133.2,x:29.2}},{t:this.instance_313},{t:this.instance_312},{t:this.instance_79,p:{x:79,y:366,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:227,y:366,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_311},{t:this.instance_310},{t:this.instance_309},{t:this.instance_308},{t:this.instance_307},{t:this.instance_306},{t:this.instance_305},{t:this.instance_304},{t:this.instance_303},{t:this.instance_302},{t:this.instance_301},{t:this.instance_150,p:{x:526,y:366,scaleX:0.1079,scaleY:0.128}},{t:this.instance_190,p:{x:370,y:366,scaleX:0.1079,scaleY:0.128}},{t:this.btnTidak15},{t:this.btnYa15},{t:this.text_1,p:{x:572.1,y:666.05,lineWidth:94}},{t:this.text,p:{x:705.3,y:666.05,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}}]},3).to({state:[{t:this.instance_86,p:{x:34.3,y:127.35}},{t:this.instance_316},{t:this.instance_315},{t:this.instance_314},{t:this.btnnext16},{t:this.text,p:{x:1231.95,y:655.95,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}},{t:this.btnhomeberkas},{t:this.btnbackberkas}]},2).to({state:[{t:this.instance_98,p:{y:126.25,x:32.25}},{t:this.instance_329},{t:this.instance_328},{t:this.instance_79,p:{x:82,y:359,scaleX:0.2061,scaleY:0.241}},{t:this.instance_78,p:{x:230,y:359,scaleX:0.2472,scaleY:0.2366}},{t:this.instance_327},{t:this.instance_326},{t:this.instance_325},{t:this.instance_324},{t:this.instance_323},{t:this.instance_322},{t:this.instance_321},{t:this.instance_320},{t:this.instance_319},{t:this.instance_318},{t:this.instance_317},{t:this.instance_190,p:{x:529,y:358,scaleX:0.1079,scaleY:0.128}},{t:this.instance_150,p:{x:380,y:359,scaleX:0.1079,scaleY:0.128}},{t:this.btnTidak16},{t:this.btnYa16},{t:this.text_1,p:{x:577.9,y:658.15,lineWidth:94}},{t:this.text,p:{x:708.35,y:658.15,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}},{t:this.btnhome16},{t:this.btnback16}]},3).to({state:[{t:this.instance_86,p:{x:30.2,y:129.45}},{t:this.instance_332},{t:this.instance_331},{t:this.instance_330},{t:this.btnnext17},{t:this.text,p:{x:1227.85,y:658.05,text:"Selanjutnya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:135}},{t:this.btnhomebeda},{t:this.btnbackbeda}]},2).to({state:[{t:this.instance_98,p:{y:126.2,x:34.3}},{t:this.instance_347},{t:this.instance_346},{t:this.instance_79,p:{x:63,y:359,scaleX:0.1525,scaleY:0.1661}},{t:this.instance_78,p:{x:180,y:359,scaleX:0.1828,scaleY:0.1632}},{t:this.instance_345},{t:this.instance_344},{t:this.instance_343},{t:this.instance_342},{t:this.instance_341},{t:this.instance_340},{t:this.instance_339},{t:this.instance_338},{t:this.instance_337},{t:this.instance_336},{t:this.instance_335},{t:this.instance_150,p:{x:307,y:359,scaleX:0.0798,scaleY:0.0883}},{t:this.instance_118,p:{x:439,y:359,scaleX:0.0798,scaleY:0.0883}},{t:this.instance_334},{t:this.instance_333},{t:this.instance_190,p:{x:566,y:359,scaleX:0.0798,scaleY:0.0883}},{t:this.btnTidak17},{t:this.btnYa17},{t:this.text_1,p:{x:578.15,y:658.1,lineWidth:94}},{t:this.text,p:{x:709.05,y:658.1,text:"Ya",font:"20px 'Tw Cen MT Condensed Extra Bold'",lineHeight:23.65,lineWidth:94}},{t:this.btnhome17},{t:this.btnback17}]},3).wait(2));

	// Layer_1
	this.instance_348 = new lib.CachedBmp_768();
	this.instance_348.setTransform(1632.5,349.9,0.5,0.5);

	this.btninfo = new lib.tombolinfo_1();
	this.btninfo.name = "btninfo";
	this.btninfo.setTransform(982.2,404.2,1.522,1.602,0,0,0,50.1,50.1);

	this.btnloket = new lib.tombolloket_1();
	this.btnloket.name = "btnloket";
	this.btnloket.setTransform(665.1,404.2,1.522,1.602,0,0,0,50,50.1);

	this.btnlayanan = new lib.tombollayanan_1();
	this.btnlayanan.name = "btnlayanan";
	this.btnlayanan.setTransform(353.15,404.05,1.522,1.602,0,0,0,50.1,50);

	this.instance_349 = new lib.CachedBmp_767();
	this.instance_349.setTransform(196.35,63.2,0.5,0.5);

	this.instance_350 = new lib.CachedBmp_766();
	this.instance_350.setTransform(191.4,0,0.5,0.5);

	this.logokota1_1 = new lib.logokota1();
	this.logokota1_1.name = "logokota1_1";
	this.logokota1_1.setTransform(87.1,55.15,0.1358,0.1296,0,0,180,638.6,425.4);

	this.instance_351 = new lib.BGweb();
	this.instance_351.setTransform(0,110,1.0703,0.7327);

	this.instance_352 = new lib.CachedBmp_765();
	this.instance_352.setTransform(0,0,0.5,0.5);

	this.instance_353 = new lib.CachedBmp_771();
	this.instance_353.setTransform(196.35,63.2,0.5,0.5);

	this.instance_354 = new lib.CachedBmp_770();
	this.instance_354.setTransform(191.4,0,0.5,0.5);

	this.instance_355 = new lib.CachedBmp_769();
	this.instance_355.setTransform(0,0,0.5,0.5);

	this.btnback2 = new lib.btnback2();
	this.btnback2.name = "btnback2";
	this.btnback2.setTransform(178.6,179.55,1,1,0,0,0,44,44);

	this.btnhome2 = new lib.btnhome2();
	this.btnhome2.name = "btnhome2";
	this.btnhome2.setTransform(68.55,179.55,1,1,0,0,0,44,44);

	this.instance_356 = new lib.CachedBmp_774();
	this.instance_356.setTransform(196.35,63.2,0.5,0.5);

	this.instance_357 = new lib.CachedBmp_773();
	this.instance_357.setTransform(191.4,0,0.5,0.5);

	this.instance_358 = new lib.CachedBmp_850();
	this.instance_358.setTransform(0,0,0.5,0.5);

	this.btnback2_2 = new lib.btnback2_2();
	this.btnback2_2.name = "btnback2_2";
	this.btnback2_2.setTransform(188,163,1,1,0,0,0,44,44);

	this.btnhome2_2 = new lib.btnhome2_2();
	this.btnhome2_2.name = "btnhome2_2";
	this.btnhome2_2.setTransform(80,163,1,1,0,0,0,44,44);

	this.instance_359 = new lib.CachedBmp_778();
	this.instance_359.setTransform(690.65,274.85,0.5,0.5);

	this.instance_360 = new lib.CachedBmp_777();
	this.instance_360.setTransform(196.35,63.2,0.5,0.5);

	this.instance_361 = new lib.CachedBmp_776();
	this.instance_361.setTransform(191.4,0,0.5,0.5);

	this.instance_362 = new lib.CachedBmp_781();
	this.instance_362.setTransform(196.35,63.2,0.5,0.5);

	this.instance_363 = new lib.CachedBmp_780();
	this.instance_363.setTransform(191.4,0,0.5,0.5);

	this.instance_364 = new lib.CachedBmp_892();
	this.instance_364.setTransform(0,0,0.5,0.5);

	this.btnbackakta = new lib.btnbackakta();
	this.btnbackakta.name = "btnbackakta";
	this.btnbackakta.setTransform(189,159,1,1,0,0,0,44,44);

	this.btnhomeakta = new lib.btnhomeakta();
	this.btnhomeakta.name = "btnhomeakta";
	this.btnhomeakta.setTransform(81,159,1,1,0,0,0,44,44);

	this.instance_365 = new lib.CachedBmp_785();
	this.instance_365.setTransform(690.65,274.85,0.5,0.5);

	this.instance_366 = new lib.CachedBmp_784();
	this.instance_366.setTransform(196.35,63.2,0.5,0.5);

	this.instance_367 = new lib.CachedBmp_783();
	this.instance_367.setTransform(191.4,0,0.5,0.5);

	this.instance_368 = new lib.CachedBmp_788();
	this.instance_368.setTransform(196.35,63.2,0.5,0.5);

	this.instance_369 = new lib.CachedBmp_787();
	this.instance_369.setTransform(191.4,0,0.5,0.5);

	this.btnbackktp2 = new lib.btnbackktp2();
	this.btnbackktp2.name = "btnbackktp2";
	this.btnbackktp2.setTransform(189,166,1,1,0,0,0,44,44);

	this.btnhomektp2 = new lib.btnhomektp2();
	this.btnhomektp2.name = "btnhomektp2";
	this.btnhomektp2.setTransform(82,166,1,1,0,0,0,44,44);

	this.text_3 = new cjs.Text("Ya", "20px 'Tw Cen MT Condensed Extra Bold'", "#FFFFFF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 24;
	this.text_3.lineWidth = 94;
	this.text_3.parent = this;
	this.text_3.setTransform(705.35,649.6);

	this.btnYa = new lib.btnYa2();
	this.btnYa.name = "btnYa";
	this.btnYa.setTransform(703.95,660.2,1,1,0,0,0,57.6,18);

	this.instance_370 = new lib.CachedBmp_803();
	this.instance_370.setTransform(434.1,586.95,0.5,0.5);

	this.instance_371 = new lib.CachedBmp_802();
	this.instance_371.setTransform(680.9,310.75,0.5,0.5);

	this.instance_372 = new lib.CachedBmp_801();
	this.instance_372.setTransform(642.4,245.8,0.5,0.5);

	this.instance_373 = new lib.CachedBmp_800();
	this.instance_373.setTransform(213.25,481.7,0.5,0.5);

	this.instance_374 = new lib.CachedBmp_799();
	this.instance_374.setTransform(392.25,481.7,0.5,0.5);

	this.instance_375 = new lib.CachedBmp_798();
	this.instance_375.setTransform(45.4,481.7,0.5,0.5);

	this.instance_376 = new lib.BukuNikah();
	this.instance_376.setTransform(233,351,0.226,0.2354);

	this.instance_377 = new lib.CachedBmp_797();
	this.instance_377.setTransform(370.85,347.15,0.5,0.5);

	this.instance_378 = new lib.CachedBmp_796();
	this.instance_378.setTransform(211.85,347.15,0.5,0.5);

	this.instance_379 = new lib.CachedBmp_795();
	this.instance_379.setTransform(53.95,347.6,0.5,0.5);

	this.instance_380 = new lib.KTP();
	this.instance_380.setTransform(403,351,0.2472,0.2366);

	this.instance_381 = new lib.KartuKeluarga();
	this.instance_381.setTransform(76,348,0.2061,0.241);

	this.instance_382 = new lib.CachedBmp_794();
	this.instance_382.setTransform(29.75,302.65,0.5,0.5);

	this.instance_383 = new lib.CachedBmp_793();
	this.instance_383.setTransform(60.35,241.45,0.5,0.5);

	this.instance_384 = new lib.CachedBmp_792();
	this.instance_384.setTransform(690.65,274.85,0.5,0.5);

	this.instance_385 = new lib.CachedBmp_791();
	this.instance_385.setTransform(196.35,63.2,0.5,0.5);

	this.instance_386 = new lib.CachedBmp_790();
	this.instance_386.setTransform(191.4,0,0.5,0.5);

	this.instance_387 = new lib.CachedBmp_789();
	this.instance_387.setTransform(0,0,0.5,0.5);

	this.instance_388 = new lib.CachedBmp_806();
	this.instance_388.setTransform(196.35,63.2,0.5,0.5);

	this.instance_389 = new lib.CachedBmp_805();
	this.instance_389.setTransform(191.4,0,0.5,0.5);

	this.instance_390 = new lib.CachedBmp_804();
	this.instance_390.setTransform(0,0,0.5,0.5);

	this.btnbackkia2 = new lib.btnbackkia2();
	this.btnbackkia2.name = "btnbackkia2";
	this.btnbackkia2.setTransform(196,169,1,1,0,0,0,44,44);

	this.btnhomekia2 = new lib.btnhomekia2();
	this.btnhomekia2.name = "btnhomekia2";
	this.btnhomekia2.setTransform(87,169,1,1,0,0,0,44,44);

	this.instance_391 = new lib.CachedBmp_809();
	this.instance_391.setTransform(196.35,63.2,0.5,0.5);

	this.instance_392 = new lib.CachedBmp_808();
	this.instance_392.setTransform(191.4,0,0.5,0.5);

	this.instance_393 = new lib.CachedBmp_812();
	this.instance_393.setTransform(196.35,63.2,0.5,0.5);

	this.instance_394 = new lib.CachedBmp_811();
	this.instance_394.setTransform(191.4,0,0.5,0.5);

	this.instance_395 = new lib.CachedBmp_889();
	this.instance_395.setTransform(0,0,0.5,0.5);

	this.btnbackmati2 = new lib.btnbackmati2();
	this.btnbackmati2.name = "btnbackmati2";
	this.btnbackmati2.setTransform(189,171,1,1,0,0,0,44,44);

	this.btnhomemati2 = new lib.btnhomemati2();
	this.btnhomemati2.name = "btnhomemati2";
	this.btnhomemati2.setTransform(79,171,1,1,0,0,0,44,44);

	this.instance_396 = new lib.CachedBmp_816();
	this.instance_396.setTransform(686.15,274.85,0.5,0.5);

	this.instance_397 = new lib.CachedBmp_815();
	this.instance_397.setTransform(191.85,63.2,0.5,0.5);

	this.instance_398 = new lib.CachedBmp_814();
	this.instance_398.setTransform(186.9,0,0.5,0.5);

	this.instance_399 = new lib.CachedBmp_813();
	this.instance_399.setTransform(-4.5,0,0.5,0.5);

	this.instance_400 = new lib.CachedBmp_819();
	this.instance_400.setTransform(192.25,63.2,0.5,0.5);

	this.instance_401 = new lib.CachedBmp_818();
	this.instance_401.setTransform(187.3,0,0.5,0.5);

	this.instance_402 = new lib.CachedBmp_822();
	this.instance_402.setTransform(196.35,63.2,0.5,0.5);

	this.instance_403 = new lib.CachedBmp_821();
	this.instance_403.setTransform(191.4,0,0.5,0.5);

	this.btnbackkeke = new lib.btnbackkeke();
	this.btnbackkeke.name = "btnbackkeke";
	this.btnbackkeke.setTransform(196.95,164,1,1,0,0,0,44,44);

	this.btnhomekeke = new lib.btnhomekeke();
	this.btnhomekeke.name = "btnhomekeke";
	this.btnhomekeke.setTransform(86,164,1,1,0,0,0,44,44);

	this.instance_404 = new lib.CachedBmp_825();
	this.instance_404.setTransform(192.05,63.2,0.5,0.5);

	this.instance_405 = new lib.CachedBmp_824();
	this.instance_405.setTransform(187.1,0,0.5,0.5);

	this.instance_406 = new lib.CachedBmp_856();
	this.instance_406.setTransform(-4.3,0,0.5,0.5);

	this.btnbackkeke2 = new lib.btnbackkeke2();
	this.btnbackkeke2.name = "btnbackkeke2";
	this.btnbackkeke2.setTransform(194,165,1,1,0,0,0,44,44);

	this.btnhomekeke2 = new lib.btnhomekeke2();
	this.btnhomekeke2.name = "btnhomekeke2";
	this.btnhomekeke2.setTransform(84.1,165,1,1,0,0,0,44,44);

	this.instance_407 = new lib.CachedBmp_828();
	this.instance_407.setTransform(196.35,63.2,0.5,0.5);

	this.instance_408 = new lib.CachedBmp_827();
	this.instance_408.setTransform(191.4,0,0.5,0.5);

	this.instance_409 = new lib.homenikah1();
	this.instance_409.setTransform(207,249,0.1913,0.1868);

	this.instance_410 = new lib.CachedBmp_831();
	this.instance_410.setTransform(196.5,63.2,0.5,0.5);

	this.instance_411 = new lib.CachedBmp_830();
	this.instance_411.setTransform(191.55,0,0.5,0.5);

	this.instance_412 = new lib.CachedBmp_829();
	this.instance_412.setTransform(0.15,0,0.5,0.5);

	this.instance_413 = new lib.CachedBmp_834();
	this.instance_413.setTransform(196.35,63.2,0.5,0.5);

	this.instance_414 = new lib.CachedBmp_833();
	this.instance_414.setTransform(191.4,0,0.5,0.5);

	this.instance_415 = new lib.CachedBmp_837();
	this.instance_415.setTransform(196.35,63.2,0.5,0.5);

	this.instance_416 = new lib.CachedBmp_836();
	this.instance_416.setTransform(191.4,0,0.5,0.5);

	this.instance_417 = new lib.CachedBmp_835();
	this.instance_417.setTransform(0,0,0.5,0.5);

	this.btnback9_1 = new lib.btnback9_1();
	this.btnback9_1.name = "btnback9_1";
	this.btnback9_1.setTransform(201,167,1,1,0,0,0,44,44);

	this.btnhome9_1 = new lib.btnhome9_1();
	this.btnhome9_1.name = "btnhome9_1";
	this.btnhome9_1.setTransform(85,167,1,1,0,0,0,44,44);

	this.instance_418 = new lib.CachedBmp_840();
	this.instance_418.setTransform(196.35,63.2,0.5,0.5);

	this.instance_419 = new lib.CachedBmp_839();
	this.instance_419.setTransform(191.4,0,0.5,0.5);

	this.instance_420 = new lib.CachedBmp_843();
	this.instance_420.setTransform(196.35,63.2,0.5,0.5);

	this.instance_421 = new lib.CachedBmp_842();
	this.instance_421.setTransform(191.4,0,0.5,0.5);

	this.instance_422 = new lib.CachedBmp_846();
	this.instance_422.setTransform(196.35,63.2,0.5,0.5);

	this.instance_423 = new lib.CachedBmp_845();
	this.instance_423.setTransform(191.4,0,0.5,0.5);

	this.instance_424 = new lib.CachedBmp_850copy2();
	this.instance_424.setTransform(0,0,0.5,0.5);

	this.btnback11 = new lib.btnback11();
	this.btnback11.name = "btnback11";
	this.btnback11.setTransform(189,173,1,1,0,0,0,44,44);

	this.btnhome11 = new lib.btnhome11();
	this.btnhome11.name = "btnhome11";
	this.btnhome11.setTransform(77,173,1,1,0,0,0,44,44);

	this.instance_425 = new lib.CachedBmp_849();
	this.instance_425.setTransform(196.35,67.6,0.5,0.5);

	this.instance_426 = new lib.CachedBmp_848();
	this.instance_426.setTransform(191.4,4.4,0.5,0.5);

	this.btnbackdom = new lib.btnbackdom();
	this.btnbackdom.name = "btnbackdom";
	this.btnbackdom.setTransform(194,171,1,1,0,0,0,44,44);

	this.btnhomedom = new lib.btnhomedom();
	this.btnhomedom.name = "btnhomedom";
	this.btnhomedom.setTransform(85,171,1,1,0,0,0,44,44);

	this.instance_427 = new lib.CachedBmp_852();
	this.instance_427.setTransform(196.35,63.2,0.5,0.5);

	this.instance_428 = new lib.CachedBmp_851();
	this.instance_428.setTransform(191.4,0,0.5,0.5);

	this.instance_429 = new lib.CachedBmp_855();
	this.instance_429.setTransform(196.75,63.2,0.5,0.5);

	this.instance_430 = new lib.CachedBmp_854();
	this.instance_430.setTransform(191.8,0,0.5,0.5);

	this.btnbackbpjs = new lib.btnbackbpjs();
	this.btnbackbpjs.name = "btnbackbpjs";
	this.btnbackbpjs.setTransform(194,161,1,1,0,0,0,44,44);

	this.btnhomebpjs = new lib.btnhomebpjs();
	this.btnhomebpjs.name = "btnhomebpjs";
	this.btnhomebpjs.setTransform(88,161,1,1,0,0,0,44,44);

	this.instance_431 = new lib.CachedBmp_858();
	this.instance_431.setTransform(196.35,63.2,0.5,0.5);

	this.instance_432 = new lib.CachedBmp_857();
	this.instance_432.setTransform(191.4,0,0.5,0.5);

	this.instance_433 = new lib.CachedBmp_861();
	this.instance_433.setTransform(196.75,63.2,0.5,0.5);

	this.instance_434 = new lib.CachedBmp_860();
	this.instance_434.setTransform(191.8,0,0.5,0.5);

	this.btnback13 = new lib.btnback13();
	this.btnback13.name = "btnback13";
	this.btnback13.setTransform(196,171,1,1,0,0,0,44,44);

	this.btnhome13 = new lib.btnhome13();
	this.btnhome13.name = "btnhome13";
	this.btnhome13.setTransform(85,171,1,1,0,0,0,44,44);

	this.instance_435 = new lib.CachedBmp_866();
	this.instance_435.setTransform(196.35,63.2,0.5,0.5);

	this.instance_436 = new lib.CachedBmp_865();
	this.instance_436.setTransform(191.4,0,0.5,0.5);

	this.logokota1_2 = new lib.logokota1();
	this.logokota1_2.name = "logokota1_2";
	this.logokota1_2.setTransform(87.1,55.15,0.1358,0.1296,0,0,180,638.6,425.4);

	this.instance_437 = new lib.CachedBmp_864();
	this.instance_437.setTransform(196.35,63.2,0.5,0.5);

	this.instance_438 = new lib.CachedBmp_863();
	this.instance_438.setTransform(191.4,0,0.5,0.5);

	this.instance_439 = new lib.BGweb();
	this.instance_439.setTransform(0,109,1.0703,0.7327);

	this.instance_440 = new lib.CachedBmp_869();
	this.instance_440.setTransform(196.75,63.2,0.5,0.5);

	this.instance_441 = new lib.CachedBmp_868();
	this.instance_441.setTransform(191.8,0,0.5,0.5);

	this.btnback14 = new lib.btnback14();
	this.btnback14.name = "btnback14";
	this.btnback14.setTransform(203.1,174.75,1,1,0,0,0,44,44);

	this.btnhome14 = new lib.btnhome14();
	this.btnhome14.name = "btnhome14";
	this.btnhome14.setTransform(87.8,174.75,1,1,0,0,0,44,44);

	this.instance_442 = new lib.CachedBmp_874();
	this.instance_442.setTransform(196.35,63.2,0.5,0.5);

	this.instance_443 = new lib.CachedBmp_873();
	this.instance_443.setTransform(191.4,0,0.5,0.5);

	this.instance_444 = new lib.CachedBmp_872();
	this.instance_444.setTransform(196.35,63.2,0.5,0.5);

	this.instance_445 = new lib.CachedBmp_871();
	this.instance_445.setTransform(191.4,0,0.5,0.5);

	this.instance_446 = new lib.CachedBmp_877();
	this.instance_446.setTransform(196.75,63.2,0.5,0.5);

	this.instance_447 = new lib.CachedBmp_876();
	this.instance_447.setTransform(191.8,0,0.5,0.5);

	this.btnback15 = new lib.btnback15();
	this.btnback15.name = "btnback15";
	this.btnback15.setTransform(189,176,1,1,0,0,0,44,44);

	this.btnhome15 = new lib.btnhome15();
	this.btnhome15.name = "btnhome15";
	this.btnhome15.setTransform(80,176,1,1,0,0,0,44,44);

	this.instance_448 = new lib.CachedBmp_882();
	this.instance_448.setTransform(196.35,63.2,0.5,0.5);

	this.instance_449 = new lib.CachedBmp_881();
	this.instance_449.setTransform(191.4,0,0.5,0.5);

	this.instance_450 = new lib.CachedBmp_880();
	this.instance_450.setTransform(196.35,63.2,0.5,0.5);

	this.instance_451 = new lib.CachedBmp_879();
	this.instance_451.setTransform(191.4,0,0.5,0.5);

	this.instance_452 = new lib.CachedBmp_885();
	this.instance_452.setTransform(196.75,63.2,0.5,0.5);

	this.instance_453 = new lib.CachedBmp_884();
	this.instance_453.setTransform(191.8,0,0.5,0.5);

	this.instance_454 = new lib.CachedBmp_888();
	this.instance_454.setTransform(196.75,63.2,0.5,0.5);

	this.instance_455 = new lib.CachedBmp_887();
	this.instance_455.setTransform(191.8,0,0.5,0.5);

	this.instance_456 = new lib.CachedBmp_891();
	this.instance_456.setTransform(196.75,63.2,0.5,0.5);

	this.instance_457 = new lib.CachedBmp_890();
	this.instance_457.setTransform(191.8,0,0.5,0.5);

	this.instance_458 = new lib.CachedBmp_894();
	this.instance_458.setTransform(196.75,63.2,0.5,0.5);

	this.instance_459 = new lib.CachedBmp_893();
	this.instance_459.setTransform(191.8,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_352},{t:this.instance_351,p:{y:110,x:0}},{t:this.logokota1_1,p:{x:87.1,y:55.15}},{t:this.instance_350},{t:this.instance_349},{t:this.btnlayanan},{t:this.btnloket},{t:this.btninfo},{t:this.instance_348}]}).to({state:[{t:this.instance_355},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_354},{t:this.instance_353},{t:this.logokota1_1,p:{x:87.1,y:55.15}}]},4).to({state:[{t:this.instance_358},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_357},{t:this.instance_356},{t:this.btnhome2},{t:this.btnback2},{t:this.logokota1_1,p:{x:87.1,y:55.15}}]},5).to({state:[{t:this.instance_358},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_361},{t:this.instance_360},{t:this.instance_359},{t:this.btnhome2_2},{t:this.btnback2_2},{t:this.logokota1_1,p:{x:87.1,y:55.15}}]},2).to({state:[]},3).to({state:[{t:this.instance_364,p:{x:0}},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_363},{t:this.instance_362},{t:this.logokota1_1,p:{x:87.1,y:55.15}}]},26).to({state:[{t:this.instance_358},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_367},{t:this.instance_366},{t:this.instance_365},{t:this.logokota1_1,p:{x:87.1,y:55.15}},{t:this.btnhomeakta},{t:this.btnbackakta}]},3).to({state:[{t:this.instance_364,p:{x:0}},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_369},{t:this.instance_368},{t:this.logokota1_1,p:{x:87.1,y:55.15}}]},2).to({state:[{t:this.instance_387},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_386},{t:this.instance_385},{t:this.instance_384},{t:this.logokota1_1,p:{x:87.1,y:55.15}},{t:this.instance_383},{t:this.instance_382},{t:this.instance_381},{t:this.instance_380},{t:this.instance_379},{t:this.instance_378},{t:this.instance_377},{t:this.instance_376},{t:this.instance_375},{t:this.instance_374},{t:this.instance_373},{t:this.instance_372},{t:this.instance_371},{t:this.instance_370},{t:this.btnYa},{t:this.text_3},{t:this.btnhomektp2},{t:this.btnbackktp2}]},3).to({state:[{t:this.instance_390},{t:this.instance_351,p:{y:111,x:0}},{t:this.instance_389},{t:this.instance_388},{t:this.logokota1_1,p:{x:87.1,y:55.15}}]},2).to({state:[{t:this.instance_358},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_392},{t:this.instance_391},{t:this.logokota1_1,p:{x:87.1,y:55.15}},{t:this.btnhomekia2},{t:this.btnbackkia2}]},3).to({state:[{t:this.instance_395,p:{x:0}},{t:this.instance_351,p:{y:110,x:1}},{t:this.instance_394},{t:this.instance_393},{t:this.logokota1_1,p:{x:87.1,y:55.15}}]},2).to({state:[{t:this.instance_399},{t:this.instance_351,p:{y:110,x:-4}},{t:this.instance_398},{t:this.instance_397},{t:this.instance_396},{t:this.logokota1_1,p:{x:82.6,y:55.15}},{t:this.btnhomemati2},{t:this.btnbackmati2}]},3).to({state:[{t:this.instance_395,p:{x:-4.1}},{t:this.instance_351,p:{y:110,x:-4}},{t:this.instance_401},{t:this.instance_400},{t:this.logokota1_1,p:{x:83,y:55.15}}]},2).to({state:[{t:this.instance_358},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_403},{t:this.instance_402},{t:this.logokota1_1,p:{x:87.1,y:55.15}}]},3).to({state:[{t:this.instance_406,p:{x:-4.3,y:0}},{t:this.instance_351,p:{y:110,x:-4}},{t:this.instance_405},{t:this.instance_404},{t:this.logokota1_1,p:{x:82.8,y:55.15}},{t:this.btnhomekeke},{t:this.btnbackkeke}]},2).to({state:[{t:this.instance_358},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_408},{t:this.instance_407},{t:this.logokota1_1,p:{x:87.1,y:55.15}},{t:this.btnhomekeke2},{t:this.btnbackkeke2}]},3).to({state:[{t:this.instance_412},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_411},{t:this.instance_410},{t:this.logokota1_1,p:{x:87.25,y:55.15}},{t:this.instance_409}]},2).to({state:[{t:this.instance_358},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_414},{t:this.instance_413},{t:this.logokota1_1,p:{x:87.1,y:55.15}}]},3).to({state:[{t:this.instance_417},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_416},{t:this.instance_415},{t:this.logokota1_1,p:{x:87.1,y:55.15}}]},2).to({state:[{t:this.instance_358},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_419},{t:this.instance_418},{t:this.logokota1_1,p:{x:87.1,y:55.15}},{t:this.btnhome9_1},{t:this.btnback9_1}]},3).to({state:[{t:this.instance_406,p:{x:0,y:0}},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_421},{t:this.instance_420},{t:this.logokota1_1,p:{x:87.1,y:55.15}}]},2).to({state:[{t:this.instance_424},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_423},{t:this.instance_422},{t:this.logokota1_1,p:{x:87.1,y:55.15}}]},3).to({state:[{t:this.instance_406,p:{x:0,y:4.4}},{t:this.instance_351,p:{y:114,x:0}},{t:this.instance_426},{t:this.instance_425},{t:this.logokota1_1,p:{x:87.1,y:59.55}},{t:this.btnhome11},{t:this.btnback11}]},2).to({state:[{t:this.instance_424},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_428},{t:this.instance_427},{t:this.logokota1_1,p:{x:87.1,y:55.15}},{t:this.btnhomedom},{t:this.btnbackdom}]},3).to({state:[{t:this.instance_406,p:{x:0.4,y:0}},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_430},{t:this.instance_429},{t:this.logokota1_1,p:{x:87.5,y:55.15}}]},2).to({state:[{t:this.instance_406,p:{x:0,y:0}},{t:this.instance_351,p:{y:109,x:0}},{t:this.instance_432},{t:this.instance_431},{t:this.logokota1_1,p:{x:87.1,y:55.15}},{t:this.btnhomebpjs},{t:this.btnbackbpjs}]},3).to({state:[{t:this.instance_395,p:{x:0.4}},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_434},{t:this.instance_433},{t:this.logokota1_1,p:{x:87.5,y:55.15}}]},2).to({state:[{t:this.instance_364,p:{x:0}},{t:this.instance_439},{t:this.instance_438},{t:this.instance_437},{t:this.logokota1_2},{t:this.instance_351,p:{y:109,x:0}},{t:this.instance_436},{t:this.instance_435},{t:this.logokota1_1,p:{x:87.1,y:55.15}},{t:this.btnhome13},{t:this.btnback13}]},3).to({state:[{t:this.instance_395,p:{x:0.4}},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_441},{t:this.instance_440},{t:this.logokota1_1,p:{x:87.5,y:55.15}}]},2).to({state:[{t:this.instance_364,p:{x:0}},{t:this.instance_439},{t:this.instance_445},{t:this.instance_444},{t:this.logokota1_2},{t:this.instance_351,p:{y:109,x:0}},{t:this.instance_443},{t:this.instance_442},{t:this.logokota1_1,p:{x:87.1,y:55.15}},{t:this.btnhome14},{t:this.btnback14}]},3).to({state:[{t:this.instance_395,p:{x:0.4}},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_447},{t:this.instance_446},{t:this.logokota1_1,p:{x:87.5,y:55.15}}]},2).to({state:[{t:this.instance_364,p:{x:0}},{t:this.instance_439},{t:this.instance_451},{t:this.instance_450},{t:this.logokota1_2},{t:this.instance_351,p:{y:109,x:0}},{t:this.instance_449},{t:this.instance_448},{t:this.logokota1_1,p:{x:87.1,y:55.15}},{t:this.btnhome15},{t:this.btnback15}]},3).to({state:[{t:this.instance_395,p:{x:0.4}},{t:this.instance_351,p:{y:111,x:0}},{t:this.instance_453},{t:this.instance_452},{t:this.logokota1_1,p:{x:87.5,y:55.15}}]},2).to({state:[{t:this.instance_364,p:{x:0.4}},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_455},{t:this.instance_454},{t:this.logokota1_1,p:{x:87.5,y:55.15}}]},3).to({state:[{t:this.instance_395,p:{x:0.4}},{t:this.instance_351,p:{y:111,x:0}},{t:this.instance_457},{t:this.instance_456},{t:this.logokota1_1,p:{x:87.5,y:55.15}}]},2).to({state:[{t:this.instance_364,p:{x:0.4}},{t:this.instance_351,p:{y:110,x:0}},{t:this.instance_459},{t:this.instance_458},{t:this.logokota1_1,p:{x:87.5,y:55.15}}]},3).wait(2));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1642.5,772.4);
// library properties:
lib.properties = {
	id: '08588B674F254E48B9D9B61159E63E2E',
	width: 1366,
	height: 768,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/CachedBmp_850copy2.png", id:"CachedBmp_850copy2"},
		{src:"images/CachedBmp_835.png", id:"CachedBmp_835"},
		{src:"images/CachedBmp_829.png", id:"CachedBmp_829"},
		{src:"images/CachedBmp_856.png", id:"CachedBmp_856"},
		{src:"images/CachedBmp_813.png", id:"CachedBmp_813"},
		{src:"images/CachedBmp_889.png", id:"CachedBmp_889"},
		{src:"images/CachedBmp_804.png", id:"CachedBmp_804"},
		{src:"images/CachedBmp_789.png", id:"CachedBmp_789"},
		{src:"images/CachedBmp_892.png", id:"CachedBmp_892"},
		{src:"images/CachedBmp_769.png", id:"CachedBmp_769"},
		{src:"images/CachedBmp_765.png", id:"CachedBmp_765"},
		{src:"images/CachedBmp_748.png", id:"CachedBmp_748"},
		{src:"images/CachedBmp_747.png", id:"CachedBmp_747"},
		{src:"images/CachedBmp_730.png", id:"CachedBmp_730"},
		{src:"images/CachedBmp_729.png", id:"CachedBmp_729"},
		{src:"images/CachedBmp_712.png", id:"CachedBmp_712"},
		{src:"images/CachedBmp_711.png", id:"CachedBmp_711"},
		{src:"images/CachedBmp_694.png", id:"CachedBmp_694"},
		{src:"images/CachedBmp_693.png", id:"CachedBmp_693"},
		{src:"images/CachedBmp_676.png", id:"CachedBmp_676"},
		{src:"images/CachedBmp_675.png", id:"CachedBmp_675"},
		{src:"images/CachedBmp_659.png", id:"CachedBmp_659"},
		{src:"images/CachedBmp_658.png", id:"CachedBmp_658"},
		{src:"images/CachedBmp_641.png", id:"CachedBmp_641"},
		{src:"images/CachedBmp_640.png", id:"CachedBmp_640"},
		{src:"images/CachedBmp_624.png", id:"CachedBmp_624"},
		{src:"images/CachedBmp_623.png", id:"CachedBmp_623"},
		{src:"images/CachedBmp_609.png", id:"CachedBmp_609"},
		{src:"images/CachedBmp_607.png", id:"CachedBmp_607"},
		{src:"images/CachedBmp_606.png", id:"CachedBmp_606"},
		{src:"images/CachedBmp_604.png", id:"CachedBmp_604"},
		{src:"images/CachedBmp_590.png", id:"CachedBmp_590"},
		{src:"images/CachedBmp_589.png", id:"CachedBmp_589"},
		{src:"images/CachedBmp_709.png", id:"CachedBmp_709"},
		{src:"images/CachedBmp_573.png", id:"CachedBmp_573"},
		{src:"images/CachedBmp_572.png", id:"CachedBmp_572"},
		{src:"images/CachedBmp_673.png", id:"CachedBmp_673"},
		{src:"images/CachedBmp_677.png", id:"CachedBmp_677"},
		{src:"images/CachedBmp_555.png", id:"CachedBmp_555"},
		{src:"images/CachedBmp_554.png", id:"CachedBmp_554"},
		{src:"images/CachedBmp_537.png", id:"CachedBmp_537"},
		{src:"images/CachedBmp_536.png", id:"CachedBmp_536"},
		{src:"images/CachedBmp_521.png", id:"CachedBmp_521"},
		{src:"images/CachedBmp_520.png", id:"CachedBmp_520"},
		{src:"images/CachedBmp_518.png", id:"CachedBmp_518"},
		{src:"images/CachedBmp_507.png", id:"CachedBmp_507"},
		{src:"images/CachedBmp_506.png", id:"CachedBmp_506"},
		{src:"images/CachedBmp_504.png", id:"CachedBmp_504"},
		{src:"images/CachedBmp_749.png", id:"CachedBmp_749"},
		{src:"images/CachedBmp_491.png", id:"CachedBmp_491"},
		{src:"images/CachedBmp_490.png", id:"CachedBmp_490"},
		{src:"images/CachedBmp_745.png", id:"CachedBmp_745"},
		{src:"images/CachedBmp_477.png", id:"CachedBmp_477"},
		{src:"images/CachedBmp_476.png", id:"CachedBmp_476"},
		{src:"images/CachedBmp_475.png", id:"CachedBmp_475"},
		{src:"images/CachedBmp_474.png", id:"CachedBmp_474"},
		{src:"images/CachedBmp_50.png", id:"CachedBmp_50"},
		{src:"images/CachedBmp_42.png", id:"CachedBmp_42"},
		{src:"images/CachedBmp_36.png", id:"CachedBmp_36"},
		{src:"images/CachedBmp_850.png", id:"CachedBmp_850"},
		{src:"images/CachedBmp_28.png", id:"CachedBmp_28"},
		{src:"images/CachedBmp_15.png", id:"CachedBmp_15"},
		{src:"images/CachedBmp_13.png", id:"CachedBmp_13"},
		{src:"images/CachedBmp_9.png", id:"CachedBmp_9"},
		{src:"images/CachedBmp_1.png", id:"CachedBmp_1"},
		{src:"images/vecteezy_facebooklogopngfacebookicontransparentpng_18930698.png", id:"vecteezy_facebooklogopngfacebookicontransparentpng_18930698"},
		{src:"images/vecteezy_instagramlogopnginstagramicontransparent_18930415.png", id:"vecteezy_instagramlogopnginstagramicontransparent_18930415"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_1.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_1"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_2.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_2"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_3.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_3"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_4.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_4"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_5.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_5"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_6.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_6"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_7.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_7"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_8.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_8"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_9.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_9"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_10.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_10"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_11.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_11"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_12.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_12"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_13.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_13"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_14.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_14"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_15.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_15"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_16.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_16"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_17.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_17"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_18.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_18"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_19.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_19"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_20.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_20"},
		{src:"images/Edukasi Pelayanan Publik _Terbaru__atlas_21.png", id:"Edukasi Pelayanan Publik _Terbaru__atlas_21"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['08588B674F254E48B9D9B61159E63E2E'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;